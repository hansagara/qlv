function Chatter(){
        this.getMessage = function(callback, lastTime){
                var t = this;
                var latest = null;
 
                $.ajax({
                        "url": "{{url('/post/ask')}}",
                        'type': 'post',
                        'dataType': 'json',
                        'data': {
                                'mode': 'get',
                                'lastTime': lastTime
                        },
                        'timeout': 30000,
                        'cache': false,
                        'success': function(result){
                                if(result.result){
                                        callback(result.message);
                                        latest = result.latest;
                                } 
                        },
                        'error': function(e){
                                console.log(e);
                        },
                        'complete': function(){
                                t.getMessage(callback, latest);
                        }
                });
        };
 
        this.postMessage = function(user, text, callback){
                $.ajax({
                        "url": "{{url('/post/ask')}}",
                        "type": "post",
                        "dataType": "json",
                        "data": {
                                "mode": "post",
                                "user": user,
                                "text": text
                        },
                        'success': function(result){
                                callback(result);
                        },
                        'error': function(e){
                                console.log(e);
                        }
                });
        };
};

var c = new Chatter();

