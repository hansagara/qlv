<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class TFounder extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_founder', function($table)
		{
			$table->increments('id');
			$table->integer('id_menu')->unsigned()->nullable();
			$table->integer('active')->nullable();
			$table->string('nama')->nullable();
			$table->string('jabatan')->nullable();
			$table->string('quotes')->nullable();
			$table->text('tentang')->nullable();
			$table->string('slug')->nullable();
			$table->string('linkedin')->nullable();
			$table->string('files')->nullable();
			$table->string('type')->nullable();
			$table->timestamps();
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_founder');
	}

}
