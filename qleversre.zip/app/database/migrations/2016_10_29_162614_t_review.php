<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class TReview extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_review', function($table)
		{
			$table->increments('id');
			$table->integer('id_from')->unsigned()->nullable();
			$table->integer('id_to')->unsigned()->nullable();
			$table->string('active')->nullable();
			$table->text('body')->nullable();
			$table->string('slug')->nullable();
			$table->string('files')->nullable();
			$table->timestamps();
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_review');
	}

}
