<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class TKelas extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_kelas', function($table)
		{
			$table->increments('id');
			$table->integer('id_jenjang')->unsigned()->nullable();
			$table->string('active')->nullable();
			$table->string('title')->nullable();
			$table->timestamps();
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_kelas');
	}

}
