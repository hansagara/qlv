<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class TMenu extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_menu', function($table)
		{
			$table->increments('id');
			$table->integer('active')->nullable();
			$table->string('title')->nullable();
			$table->string('slug')->nullable();
			$table->text('body')->nullable();
			$table->string('icon')->nullable();
			$table->string('files')->nullable();
			$table->string('type')->nullable();
			$table->timestamps();
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_menu');
	}

}
