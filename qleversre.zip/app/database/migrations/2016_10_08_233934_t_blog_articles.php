<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class TBlogArticles extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_blog_articles', function($table)
		{
			$table->increments('id');
			$table->integer('id_categories')->unsigned()->nullable();
			$table->integer('active')->nullable();
			$table->string('title')->nullable();
			$table->string('description')->nullable();
			$table->text('body')->nullable();
			$table->string('icon')->nullable();
			$table->string('files')->nullable();
			$table->string('type')->nullable();
			$table->string('slug')->nullable();
			$table->timestamps();
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_blog_articles');
	}

}
