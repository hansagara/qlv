<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class TSayembara extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('t_sayembara', function($table)
		{
			$table->increments('id');
			$table->integer('id_pelajaran')->unsigned()->nullable();
			$table->integer('id_user')->unsigned()->nullable();
			$table->string('active')->nullable();
			$table->text('body')->nullable();
			$table->string('slug')->nullable();
			$table->string('files')->nullable();
			$table->timestamps();
		});
	}

	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('t_sayembara');
	}

}
