@extends('backend/student/layout')

@section('title', 'Pertanyaan '. $tugas->ask->mapel->title)
@section('description', $tugas->ask->body)
@section('keywords', 'Soal Matematika,Soal Fisika,Soal Kimia,Soal Biologi,Soal PPKN,Soal Pancasila,Soal Agama,Soal Psikologi,Soal Sejarah,Bahasa Indonesia, Bahasa Inggris, Bahasa English, Aljabar Linier,Bahasa Pemograman,Komputer,tkj')
@section('images', URL::asset($tugas->ask->files))
@section('url', url('/'))

@section('student_css')

<style>
    .demo-table ul{padding:0px 10px 0px 10px;background: #f7f7f7;}
    .demo-table li{display:inline-block; font-size: 16px;padding: 0 1px;cursor: pointer;color: #fff;text-decoration: none; text-shadow:0 0 1px #000000;}
    .demo-table .highlight, .demo-table .selected {color:#F4B30A;text-shadow: 0 0 1px #F48F0A;}
</style>

@endsection

@section('content')

        @include('backend.student.inc.sidebar_left')
            
            <section id="content">
                <div class="container">
                    <div class="row">
                        <div class="col-md-8">

                            <div class="card">
                                <div class="card-header">
                                    <div class="media">
                                        <div class="pull-left">
                                            @if($tugas->ask->user->avatar == '')
                                                <img class="avatar-img a-lg ava" data-name="{{$tugas->ask->user->first_name}}" alt=""/>
                                            @else
                                                {{ HTML::image($tugas->ask->user->avatar,'',array('class'=>'avatar-img a-lg','alt'=>'$tugas->ask->user->first_name')) }}
                                            @endif
                                        </div>

                                        <div class="media-body m-t-5">
                                            <h2>
                                                {{$tugas->ask->user->first_name}} 
                                                <small>{{$tugas->ask->mapel->title}} - Posted on {{ Carbon::parse($tugas->created_at)->diffForHumans() }}</small>
                                            </h2>
                                        </div>
                                    </div>
                                </div>

                                <div class="card-body card-padding">
                                    <p style="font-size:18px;">
                                        {{$tugas->ask->body}}
                                    </p>

                                    @if(file_exists($tugas->ask->files))
                                        <div class="wall-img-preview lightbox clearfix">
                                            <div class="wip-item" data-src="{{ URL::asset($tugas->ask->files) }}" style="background-image: url({{ URL::asset($tugas->ask->files) }});">
                                                <div class="lightbox-item"></div>
                                            </div>
                                        </div>
                                    @else
                                    @endif

                                    <ul class="wall-attrs clearfix list-inline list-unstyled">
                                        <li class="">
                                            <div class="btn-group">
                                                <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown">
                                                    Share
                                                    <span class="caret"></span>
                                                </button>
                                                <ul class="dropdown-menu" role="menu">
                                                    <li>
                                                        <a target="_blank" href="http://www.facebook.com/sharer.php?u={{url('ask/tugas',$tugas->id)}}" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;">
                                                            <span class="zmdi zmdi-facebook-box"></span> Facebook
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a target="_blank" href="https://twitter.com/share?url={{url('ask/tugas',$tugas->id)}}&amp;text={{$tugas->ask->user->first_name}} membutuhkan bantuan kamu untuk menjawab soal&amp;hashtags=@_qlevers" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;">
                                                            <span class="zmdi zmdi-twitter-box"></span> Twitter
                                                        </a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </li>
                                        <li class="wa-users">
                                            <a href="{{url('/student/profiles/'.Sentry::getUser()->id)}}">
                                                @if(Sentry::getUser()->avatar == '')
                                                    <img class="ava" data-name="{{Sentry::getUser()->first_name}}" alt=""/>
                                                @else
                                                    {{ HTML::image(Sentry::getUser()->avatar,'',array('alt'=>'Sentry::getUser()->first_name')) }}
                                                @endif
                                            </a>
                                        </li>
                                    </ul>
                                </div>

                                <div class="wall-comment-list">
                                    <!-- Comment form -->
                                    <div class="wcl-form">
                                        <div class="wc-comment">
                                        {{ Form::open(['url' => 'post/comment', 'files' => true]) }}
                                            <div class="wcc-inner">
                                                <input type="hidden" name="ask" value="{{$tugas->ask->id}}">
                                                <input type="hidden" name="from" value="{{Sentry::getUser()->id}}">
                                                <input type="hidden" name="to" value="{{$tugas->ask->user->id}}">
                                                <textarea class="wcci-text" name="body" placeholder="Write Something..." required></textarea>
                                            </div>
                                            <div class="m-t-15">
                                                <button class="btn btn-sm btn-primary" type="submit">Post</button>
                                                <div class="fileinput fileinput-new" data-provides="fileinput">
                                                    <span class="btn btn-warning btn-sm btn-file m-r-10">
                                                        <span class="fileinput-new">Upload</span>
                                                        <span class="fileinput-exists">Ganti</span>
                                                        <input type="file" name="images" accept="image/*">
                                                    </span>
                                                    <span class="fileinput-filename"></span>
                                                    <a href="#" class="close fileinput-exists" data-dismiss="fileinput">&times;</a>
                                                </div>
                                            </div>
                                        {{ Form::close() }}
                                        </div>
                                    </div>
                                </div>

                                <div class="wall-comment-list">
                                    <!-- Comment Listing -->
                                    <div class="wcl-list">

                                    @foreach($comquery = Comment::with('ask')->with('user')->where('id_ask','=',$tugas->ask->id)->where('active','=','1')->get() as $comment)
                                        <div class="media">
                                            <a href="" class="pull-left">
                                                @if($comment->user->avatar == '')
                                                    <img class="avatar-img ava" data-name="{{$comment->user->first_name}}" alt=""/>
                                                @else
                                                    {{ HTML::image($comment->user->avatar,'',array('class'=>'avatar-img a-lg','alt'=>'$comment->user->first_name')) }}
                                                @endif
                                            </a>

                                            <div class="pull-right p-0">
                                                <ul class="actions">
                                                    <li class="dropdown" dropdown="">
                                                        <a href="" dropdown-toggle="" aria-haspopup="true" aria-expanded="false">
                                                            <i class="zmdi zmdi-more-vert"></i>
                                                        </a>

                                                        <ul class="dropdown-menu dropdown-menu-right">
                                                            <li>
                                                                <a href="">Report</a>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                </ul>
                                            </div>

                                            <div class="media-body">
                                                <a href="" class="a-title">{{$comment->user->first_name}} </a> 
                                                <small class="c-gray m-l-10">- {{ Carbon::parse($comment->created_at)->diffForHumans() }}</small>
                                                <p class="m-t-5 m-b-0" style="font-size:18px;">{{ nl2br($comment->body) }}</p>

                                                @if(file_exists($comment->files))
                                                    <div class="wall-img-preview lightbox clearfix">
                                                        <div class="wip-item" data-src="{{ URL::asset($comment->files) }}" style="background-image: url({{ URL::asset($comment->files) }});">
                                                            <div class="lightbox-item"></div>
                                                        </div>
                                                    </div>
                                                @else
                                                @endif

                                                <ul class="wall-attrs clearfix list-inline list-unstyled">
                                                        <!--
                                                    <li class="wa-stats">
                                                        <div class='starrr' id='star1'></div>
                                                        <div>
                                                          <span class='your-choice-was' style='display: none;'>
                                                            Your rating was <span class='choice'></span>.
                                                          </span>
                                                        </div>
                                                    </li>
                                                        -->
                                                    <li class="wa-users">
                                                        <table class="demo-table">
                                                            <tbody>
                                                                <tr>
                                                                    <td valign="top">
                                                                    @if($comment->id_user == Sentry::getUser()->id)
                                                                    <a href="#bacadulu" data-toggle="modal">
                                                                        <div id="bintang-{{$comment->id}}">
                                                                            <input type="hidden" name="rating" id="rating" value="{{$comment->rating}}" />
                                                                            <ul>
                                                                              <?php
                                                                                  for($i=1;$i<=5;$i++) {
                                                                                    $selected = "";
                                                                                  if(!empty($comment->rating) && $i<=$comment->rating) {
                                                                                    $selected = "selected";
                                                                                  }
                                                                              ?>
                                                                              <li class="{{ $selected }}"><i class="fa fa-star"></i></li>  
                                                                              <?php }  ?>
                                                                            </ul>
                                                                        </div>
                                                                    </a>
                                                                    @elseif($tugas->ask->id_user == Sentry::getUser()->id)
                                                                        <div id="bintang-{{$comment->id}}">
                                                                            <input type="hidden" name="rating" id="rating" value="{{$comment->rating}}" />
                                                                            <ul onMouseOut="resetRating({{$comment->id}});">
                                                                              <?php
                                                                                  for($i=1;$i<=5;$i++) {
                                                                                    $selected = "";
                                                                                  if(!empty($comment->rating) && $i<=$comment->rating) {
                                                                                    $selected = "selected";
                                                                                  }
                                                                              ?>
                                                                              <li class="{{ $selected }}" onmouseover="highlightStar(this,{{$comment->id}});" onmouseout="removeHighlight({{$comment->id}});" onClick="addRating(this,{{$comment->id}});"><i class="fa fa-star"></i></li>  
                                                                              <?php }  ?>
                                                                            </ul>
                                                                        </div>
                                                                    @else
                                                                    <a href="#bacadulu" data-toggle="modal">
                                                                        <div id="bintang-{{$comment->id}}">
                                                                            <input type="hidden" name="rating" id="rating" value="{{$comment->rating}}" />
                                                                            <ul>
                                                                              <?php
                                                                                  for($i=1;$i<=5;$i++) {
                                                                                    $selected = "";
                                                                                  if(!empty($comment->rating) && $i<=$comment->rating) {
                                                                                    $selected = "selected";
                                                                                  }
                                                                              ?>
                                                                              <li class="{{ $selected }}"><i class="fa fa-star"></i></li>  
                                                                              <?php }  ?>
                                                                            </ul>
                                                                        </div>
                                                                    </a>
                                                                    @endif
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>

                                                    </li>
                                                </ul>

                                                <!--
                                                <div class="wcl-form">
                                                    <div class="wc-comment">
                                                        <div class="wcc-inner wcc-toggle">
                                                            Write Something...
                                                        </div>
                                                    </div>
                                                </div>
                                                -->

                                            </div>
                                        </div>
                                        <hr>
                                    @endforeach

                                    </div>

                                </div>
                            </div>
                            
                        </div>

                        <div class="col-md-4 hidden-sm hidden-xs">
                            @include('backend.student.inc.sidebar_right')
                        </div>

                    </div>
                </div>
            </section>

                            <div class="modal fade" id="bacadulu" tabindex="-1" role="dialog" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header" style="background: #0c7695;">
                                            <h4 class="modal-title" style="color: #fff;">Ketentuan Penilaian / Bintang</h4>
                                        </div>
                                        <br>
                                        <div class="modal-body">
                                            <p class="c-black">Agar tidak adanya kecurangan dalam memberi penilaian / bintang, diantaranya yaitu :</p>
                                            <ol>
                                                <li>Hanya pemilik pertanyaan yang bisa memberi bintang</li>
                                                <li>Pemilik pertanyaan tidak di izinkan memberi bintang pada jawaban / komentarnya sendiri</li>
                                                <li>User yang bukan pemilik pertanyaan tidak di izinkan memberi bintang</li>
                                            </ol>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-link" data-dismiss="modal">Tutup</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
@stop

@section('student_js')
<script>
    function highlightStar(obj,id) {
        removeHighlight(id);        
        $('.demo-table #bintang-'+id+' li').each(function(index) {
            $(this).addClass('highlight');
            if(index == $('.demo-table #bintang-'+id+' li').index(obj)) {
                return false;   
            }
        });
    }

    function removeHighlight(id) {
        $('.demo-table #bintang-'+id+' li').removeClass('selected');
        $('.demo-table #bintang-'+id+' li').removeClass('highlight');
    }

    function addRating(obj,id) {
        $('.demo-table #bintang-'+id+' li').each(function(index) {
            $(this).addClass('selected');
            $('#bintang-'+id+' #rating').val((index+1));
            if(index == $('.demo-table #bintang-'+id+' li').index(obj)) {
                return false;   
            }
        });
        $.ajax({
        url: "{{url('rating/comment')}}",
        type: "POST",
        data:'id='+id+'&rating='+$('#bintang-'+id+' #rating').val(),
        beforeSend: function(request) {
            return request.setRequestHeader("X-CSRF-Token", $("meta[name='token']").attr('content'));
            }
        });
    }

    function resetRating(id) {
        if($('#bintang-'+id+' #rating').val() != 0) {
            $('.demo-table #bintang-'+id+' li').each(function(index) {
                $(this).addClass('selected');
                if((index+1) == $('#bintang-'+id+' #rating').val()) {
                    return false;   
                }
            });
        }
    } 
</script>
<script src="{{ URL::asset('assets/backend/vendors/fileinput/fileinput.min.js') }}"></script>
@endsection