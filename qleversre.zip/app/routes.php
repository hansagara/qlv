<?php

# CSRF Protection
Route::when('*', 'csrf', ['POST', 'PUT', 'PATCH', 'DELETE']);

# Static Pages. Redirecting admin so admin cannot access these pages.
Route::group(['before' => 'redirectAdmin'], function()
{
	Route::get('/', ['as' => 'home', 'uses' => 'PagesController@getHome']);
	Route::get('/pages/{id}/{date}/{slug}', ['as' => 'page', 'uses' => 'PagesController@getMenu']);
	Route::get('/pages/contact', ['as' => 'contact', 'uses' => 'PagesController@getContact']);
	Route::get('/ask/home', ['as' => 'ask', 'uses' => 'PagesController@getAsk']);
	Route::get('/ask/tugas/{id}', ['as' => 'ask', 'uses' => 'PagesController@getAskView']);

	Route::get('/team/{id}/{date}/{slug}', ['as' => 'page', 'uses' => 'PagesController@getFounder']);

	Route::get('/blog/listing', ['as' => 'blog', 'uses' => 'PagesController@getBlog']);
	Route::get('/cat/{id}/{date}/{slug}', ['as' => 'page', 'uses' => 'PagesController@getCatBlog']);
	Route::get('/read/{id}/{date}/{slug}', ['as' => 'blog_read', 'uses' => 'PagesController@getReadBlog']);

	Route::get('/rss', ['as' => 'rss', 'uses' => 'PagesController@getRss']);
	Route::get('/rss/about', ['as' => 'rss_about', 'uses' => 'PagesController@getRssAbout']);
	Route::get('/rss/team', ['as' => 'rss_about', 'uses' => 'PagesController@getRssTeam']);
	Route::get('/rss/blog', ['as' => 'rss_about', 'uses' => 'PagesController@getRssBlog']);

});

# Registration
Route::group(['before' => 'guest'], function()
{
	Route::get('/pages/register', 'RegistrationController@create');
    Route::get('/register/kelas', array('uses'=>'RegistrationController@getKelas'));
	Route::post('/post/register', ['as' => 'registration.store', 'uses' => 'RegistrationController@store']);
});

# Authentication
Route::get('/pages/login', ['as' => 'login', 'uses' => 'SessionsController@create'])->before('guest');
Route::get('logout', ['as' => 'logout', 'uses' => 'SessionsController@destroy']);
Route::resource('sessions', 'SessionsController' , ['only' => ['create','store','destroy']]);

# Authentication Social Button
Route::get('auth/google', array('as' => 'auth/google', 'uses' => 'oAuthController@Google'));
Route::get('auth/facebook', array('as' => 'auth/google', 'uses' => 'oAuthController@Facebook'));

# Forgotten Password
Route::group(['before' => 'guest'], function()
{
	Route::get('/pages/forgot_password', 'RemindersController@getRemind');
	Route::post('forgot_password','RemindersController@postRemind');
	Route::get('/pages/reset_password/{token}', 'RemindersController@getReset');
	Route::post('reset_password/{token}', 'RemindersController@postReset');
});


# Standard User Routes
Route::group(['before' => 'auth|student'], function()
{
	Route::get('/complate_form', 'UsersController@getComplate');
	Route::post('/complete/form/student/{id}','UsersController@postCompleteForm');
    Route::get('/complete/register/kelas', array('uses'=>'RegistrationController@getKelas'));

	Route::get('/student', 'StudentController@getHome');
	Route::post('/post/votes','AskController@getVotes');

	Route::get('/student/user/{id}', 'UsersController@getStudentProfiles');
	Route::post('/post/review','UsersController@getPostReview');

	Route::resource('/student/profiles', 'UsersController', ['only' => ['show', 'edit', 'update']]);

	Route::get('/student/profiles/media/{id}', 'StudentController@getStudentMedia');
	Route::get('/student/profiles/history/ask/{id}', 'StudentController@getStudentAskHistory');

	Route::get('/top/rank', 'StudentController@getRank');
	
	Route::post('/post/ask','AskController@store');
	Route::post('/tugas/notif/{id}','NotificationController@getCommentNotif');
	Route::get('/tugas/{id}', 'AskController@show');

	Route::get('/cari/tugas/', 'StudentController@getSearch');
	Route::get('/cari/pelajaran/{id}', 'StudentController@getMapelSearch');

	Route::post('/post/comment','AskController@storeComment');
	Route::post('/rating/comment','AskController@getRating');

	Route::get('/sayembara', 'SayembaraController@index');
	Route::post('/post/jawaban/sayembara','SayembaraController@storeComment');

});

# Admin Routes
Route::group(['before' => 'auth|admin'], function()
{
	Route::get('/admin', ['as' => 'admin_dashboard', 'uses' => 'AdminController@getHome']);
    Route::resource('admin/profiles', 'AdminUsersController', ['only' => ['index', 'show', 'edit', 'update', 'destroy']]);
	
	Route::get('/admin/list/blog', 'AdminController@getBlog');
	Route::get('/admin/tambah/blog', 'AdminController@getAddBlog');
	Route::post('/admin/post/blog', 'AdminController@getPostBlog');
	Route::get('/admin/edit/blog/{id}', 'AdminController@getEditBlog');
	Route::post('/admin/update/blog', 'AdminController@getUpdateBlog');
	Route::get('/admin/delete/blog/{id}', 'AdminController@getDeleteBlog');
	
	Route::get('/report/cart/votes', 'AdminController@cartVotes');
	Route::get('/report/cart/tugas', 'AdminController@cartTugas');
});

# Admin Routes
/*
App::error(function (Exception $exception) {
    Log::error($exception);
    $error = $exception->getMessage();
    return Response::view('404', compact('error'));
});

App::missing(function () {
    return Response::view('404', array(), 404);
});
*/