<?php

class BlogCategories extends Eloquent {
	
	public $table = 't_blog_categories';
	public $fillable = array(
		''
		);

	public static $rules = array('');

}