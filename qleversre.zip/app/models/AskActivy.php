<?php

class AskActivy extends Eloquent {
	
	public $table = 't_ask_activy';
	public $fillable = array(
		''
		);

	public static $rules = array('');

    public function ask()
    {
    	return $this->belongsTo('Ask','id_ask');
    }

}