<?php

class SayembaraComment extends Eloquent {
	
	public $table = 't_sayembara_comment';
	public $fillable = array(
		''
		);

	public static $rules = array('');

    public function sayembara()
    {
    	return $this->belongsTo('Sayembara','id_sayembara');
    }

    public function user()
    {
    	return $this->belongsTo('User','id_user');
    }

}