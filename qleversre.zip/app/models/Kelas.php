<?php

class Kelas extends Eloquent {
	
	public $table = 't_kelas';
	public $fillable = array(
		''
		);

	public static $rules = array('');

	public function jenjang()
	{
		 return $this->belongsTo('Jenjang','id_jenjang');
	}

}