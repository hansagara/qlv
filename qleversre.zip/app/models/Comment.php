<?php

class Comment extends Eloquent {
	
	public $table = 't_comment';
	public $fillable = array(
		''
		);

	public static $rules = array('');

    public function ask()
    {
    	return $this->belongsTo('Ask','id_ask');
    }

    public function user()
    {
    	return $this->belongsTo('User','id_user');
    }

}