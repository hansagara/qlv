<?php

class Votes extends Eloquent {
	
	public $table = 't_votes';
	public $fillable = array(
		''
		);

	public static $rules = array('');

	public function user()
	{
		 return $this->belongsTo('User','id_user');
	}

}