<?php

class Review extends Eloquent {
	
	public $table = 't_review';
	public $fillable = array(
		''
		);

	public static $rules = array('');

    public function user()
    {
    	return $this->belongsTo('User','id_user');
    }

}