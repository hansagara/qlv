<?php

class Founder extends Eloquent {
	
	public $table = 't_founder';
	public $fillable = array(
		''
		);

	public static $rules = array('');

    public function menu()
    {
    	return $this->belongsTo('Menu','id_menu');
    }

}