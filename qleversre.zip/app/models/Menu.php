<?php

class Menu extends Eloquent {
	
	public $table = 't_menu';
	public $fillable = array(
		''
		);

	public static $rules = array('');

}