<?php

class Ask extends Eloquent {
	
	public $table = 't_ask';
	public $fillable = array(
		''
		);

	public static $rules = array('');

    public function mapel()
    {
    	return $this->belongsTo('Pelajaran','id_pelajaran');
    }

    public function user()
    {
    	return $this->belongsTo('User','id_user');
    }

}