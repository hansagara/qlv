<?php

class CommentActivy extends Eloquent {
	
	public $table = 't_comment_activy';
	public $fillable = array(
		''
		);

	public static $rules = array('');

    public function comment()
    {
    	return $this->belongsTo('Comment','id_comment');
    }

}