<?php

class BlogArticles extends Eloquent {
	
	public $table = 't_blog_articles';
	public $fillable = array(
		''
		);

	public static $rules = array('');

    public function bcat()
    {
    	return $this->belongsTo('BlogCategories','id_categories');
    }

}