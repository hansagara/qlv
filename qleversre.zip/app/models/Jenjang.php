<?php

class Jenjang extends Eloquent {
	
	public $table = 't_jenjang';
	public $fillable = array(
		''
		);

	public static $rules = array('');

}