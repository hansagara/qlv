<?php

class Notification extends Eloquent {
	
	public $table = 't_notification';
	public $fillable = array(
		''
		);

	public static $rules = array('');

    public function ask()
    {
    	return $this->belongsTo('Ask','id_activi');
    }

    public function comment()
    {
    	return $this->belongsTo('Comment','id_activi');
    }

    public function from()
    {
    	return $this->belongsTo('User','id_from');
    }

    public function to()
    {
    	return $this->belongsTo('User','id_to');
    }
}