<?php

class Pelajaran extends Eloquent {
	
	public $table = 't_pelajaran';
	public $fillable = array(
		''
		);

	public static $rules = array('');

}