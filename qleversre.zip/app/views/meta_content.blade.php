    <link rel="shortcut icon" href="{{ URL::asset('assets/frontend/img/favicon.gif') }}">
    
    <meta name="theme-color" content="#6cd6f5">
    <meta content="Qlevers" name="author">
    <meta name="format" content="text/html" />
    <meta content='id' name='language'/>
    <meta content='id' name='geo.country'/>
    <meta content='Indonesia' name='geo.placename'/>
    <meta name="pubdate" content="@yield('pubdate')" />
    <meta itemprop="datePublished" content="@yield('pubdate')">
    <meta name="rights" content="Copyright Qlevers {{ date('Y') }} " />
    <meta name="Subject" content="Education Industry : Students Forum" />
    <meta name="type" content="Text" />
    <meta name="publisher" content="qlevers.com" />
    <meta name="retention" content="pub1100" />
    <meta name="coverage" content="Global" />
    <meta name="robots" content="index, follow, noodp, noydir" />

    <meta  name="image" content="@yield('images')"/>
    <meta name="description" content="@yield('description')">
    <meta name="keywords" content="@yield('keywords')">

    <!--Facebook-->
    <meta property="og:type" content="website"/>
    <meta property="og:title" content="Qlevers - @yield('title')"/>
    <meta property="og:site_name" content="qlevers.com"/>
    <meta property="og:image:width" content="1200" />
    <meta property="og:image:height" content="630" />
    <meta property="og:image" content="@yield('images')"/>
    <meta property="og:url" content="@yield('url')"/>
    <meta property="og:description" content="@yield('description')"/>
            
    <!--twitter-->
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:site" content="@_Qlevers">
    <meta name="twitter:site:id" content="@_Qlevers" />
    <meta name="twitter:creator" content="@_Qlevers">
    <meta name="twitter:title" content="Qlevers - @yield('title')">
    <meta name="twitter:description" content="@yield('description')">
    <meta name="twitter:image" content="@yield('images')">
    @include('ga')