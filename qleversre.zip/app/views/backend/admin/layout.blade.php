<!DOCTYPE html>
    <!--[if IE 9 ]><html class="ie9"><![endif]-->
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Qlevers - @yield('title')</title>
        @include('backend.student.inc.css')
        @include('meta_content')
    </head>

    <body data-ma-header="teal">
            
        @include('backend.student.inc.menu')
        <section id="main">
            @include('backend.student.inc.alert')
            @yield('content')
        </section>
        @include('backend.student.inc.js')
    </body>
</html>