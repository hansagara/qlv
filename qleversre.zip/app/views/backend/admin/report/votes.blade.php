@extends('backend/admin/layout')

    @section('css')

    @endsection

@section('content')
    @include('backend.admin.inc.sidebar_left')
    
            <section id="content">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <h2>Total Pertanyaan :</h2>
                                </div>
                                <div class="card-body card-padding-sm">
                                    <div id="bar-chart" class="flot-chart"></div>
                                    <div class="flc-bar"></div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
            </section>

@stop

    @section('student_js')
        <script src="{{ URL::asset('assets/backend/vendors/bower_components/flot/jquery.flot.js') }}"></script>
        <script src="{{ URL::asset('assets/backend/vendors/bower_components/flot/jquery.flot.resize.js') }}"></script>
        <script src="{{ URL::asset('assets/backend/vendors/bower_components/flot/jquery.flot.pie.js') }}"></script>
        <script src="{{ URL::asset('assets/backend/vendors/bower_components/flot.tooltip/js/jquery.flot.tooltip.min.js') }}"></script>
        <script src="{{ URL::asset('assets/backend/vendors/bower_components/flot-orderBars/js/jquery.flot.orderBars.js') }}"></script>
        <script src="{{ URL::asset('assets/backend/vendors/bower_components/flot.curvedlines/curvedLines.js') }}"></script>
        <script src="{{ URL::asset('assets/backend/vendors/bower_components/flot-orderBars/js/jquery.flot.orderBars.js') }}"></script>
        <script type="text/javascript">
            $(document).ready(function(){
    
                /* Make some random data for Flot Line Chart*/
                
                var data1 = [[1,{{Votes::where('active','=','1')->where('design','=','3')->sum('design')}}], [2,30], [3,50]];
                var data2 = [[1,20], [2,90], [3,60]];
                var data3 = [[1,100], [2,20], [3,60]];
                
                /* Create an Array push the data + Draw the bars*/
                
                var barData = new Array();

                barData.push({
                        data : data1,
                        label: 'BAIK',
                        bars : {
                                show : true,
                                barWidth : 0.08,
                                order : 1,
                                lineWidth: 0,
                                fillColor: '#edc240'
                        }
                });
                
                barData.push({
                        data : data2,
                        label: 'SEDANG',
                        bars : {
                                show : true,
                                barWidth : 0.08,
                                order : 2,
                                lineWidth: 0,
                                fillColor: '#afd8f8'
                        }
                });
                
                barData.push({
                        data : data3,
                        label: 'BURUK',
                        bars : {
                                show : true,
                                barWidth : 0.08,
                                order : 3,
                                lineWidth: 0,
                                fillColor: '#cb4b4b'
                        }
                });
                
                /* Let's create the chart */
                if ($('#bar-chart')[0]) {
                    $.plot($("#bar-chart"), barData, {
                        grid : {
                                borderWidth: 1,
                                borderColor: '#eee',
                                show : true,
                                hoverable : true,
                                clickable : true
                        },
                        
                        yaxis: {
                            tickColor: '#eee',
                            tickDecimals: 0,
                            font :{
                                lineHeight: 13,
                                style: "normal",
                                color: "#9f9f9f",
                            },
                            shadowSize: 0
                        },
                        
                        xaxis: {
                            tickColor: '#fff',
                            tickDecimals: 0,
                            font :{
                                lineHeight: 13,
                                style: "normal",
                                color: "#9f9f9f"
                            },
                            shadowSize: 0,
                        },
                
                        legend:{
                            container: '.flc-bar',
                            backgroundOpacity: 0.5,
                            noColumns: 0,
                            backgroundColor: "white",
                            lineWidth: 0
                        }
                    });
                }
                
                /* Tooltips for Flot Charts */
    
                if ($(".flot-chart")[0]) {
                    $(".flot-chart").bind("plothover", function (event, pos, item) {
                        if (item) {
                            var x = item.datapoint[0].toFixed(2),
                                y = item.datapoint[1].toFixed(2);
                            $(".flot-tooltip").html(item.series.label + " of " + x + " = " + y).css({top: item.pageY+5, left: item.pageX+5}).show();
                        }
                        else {
                            $(".flot-tooltip").hide();
                        }
                    });
                    
                    $("<div class='flot-tooltip' class='chart-tooltip'></div>").appendTo("body");
                }
            });
        </script>
    @endsection