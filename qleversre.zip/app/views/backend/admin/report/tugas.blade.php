@extends('backend/admin/layout')

    @section('css')

    @endsection

@section('content')
    @include('backend.admin.inc.sidebar_left')
    
            <section id="content">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <h2>Total Pertanyaan : {{$cart = Ask::count()}}</h2>
                                </div>
                                <div class="card palette-Blue-400 bg">
                                    <div class="pie-grid clearfix text-center">

                                        @foreach(Pelajaran::get() as $mapel)
                                            <div class="col-xs-4 col-sm-6 col-md-4 pg-item">
                                                <div class="easy-pie-2 easy-pie" data-percent="{{$cart = Ask::where('id_pelajaran','=', $mapel->id)->count() / Ask::count() }}">
                                                    <span class="ep-value">{{$cart}}</span>
                                                </div>
                                                <div class="pgi-title">{{$mapel->title}} <br> {{$cart = Ask::where('id_pelajaran','=', $mapel->id)->count()}}</div>
                                            </div>
                                        @endforeach

                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
            </section>

@stop

    @section('student_js')
        <script src="{{ URL::asset('assets/backend/vendors/bower_components/jquery.easy-pie-chart/dist/jquery.easypiechart.min.js') }}"></script>
        <script src="{{ URL::asset('assets/backend/js/charts.js') }}"></script>
    @endsection