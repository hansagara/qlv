        <aside id="s-main-menu" class="sidebar">
                <div class="col-md-12 hidden-sm hidden-xs">
          
                    <div class="card">
                        <ul class="main-menu">
                            <li>
                                <a href="{{url('/')}}"><i class="zmdi zmdi-home"></i> Home</a>
                            </li>
                            <li><a href="{{url('/admin/list/blog')}}"><i class="zmdi zmdi-format-underlined"></i> Blog</a></li>
                            <li class="sub-menu">
                                <a href="" data-ma-action="submenu-toggle"><i class="zmdi zmdi-view-list"></i> Pages</a>
                                <ul>
                                    @foreach(Menu::where('type','=','main')->where('active','=','1')->get() as $m)
                                    <li><a href="">{{$m->title}}</a></li>
                                    @endforeach
                                </ul>
                            </li>
                            <li class="sub-menu">
                                <a href="" data-ma-action="submenu-toggle"><i class="zmdi zmdi-trending-up"></i> Report</a>
                                <ul>
                                    <li><a href="{{url('/report/cart/votes/')}}">Votes</a></li>
                                    <li><a href="{{url('/report/cart/tugas/')}}">Tugas</a></li>
                                    <li><a href="colored-header.html">Kontributor</a></li>
                                    <li><a href="alternative-header.html">User</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </aside>