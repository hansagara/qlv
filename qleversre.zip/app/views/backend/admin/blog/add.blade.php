@extends('backend/admin/layout')

    @section('css')
        <link href="{{ URL::asset('assets/backend/vendors/bootgrid/jquery.bootgrid.min.css') }}" rel="stylesheet">
        <link href="{{ URL::asset('assets/backend/vendors/summernote/dist/summernote.css') }}" rel="stylesheet">
        <link href="{{ URL::asset('assets/backend/vendors/bower_components/chosen/chosen.min.css') }}" rel="stylesheet">
    @endsection

@section('content')
    @include('backend.admin.inc.sidebar_left')
    
            <section id="content">
                <div class="container">
                    
                {{ Form::open(['url' => 'admin/post/blog', 'files' => true]) }}
                    <div class="card">
                        <div class="card-header" style="float: right;">
                            <a href="javascript:history.back()" class="btn palette-Red bg"><i class="zmdi zmdi-arrow-back"></i> Batal</a>
                            <button type="submit" class="btn palette-Cyan bg"><i class="zmdi zmdi-check-all"></i> Simpan</button>
                        </div>

                        <div class="card-body card-padding">
                            <div class="form-group">
                                <div class="fg-line">
                                    <input type="text" name="title" id="title" class="form-control input-sm" placeholder="Title" required>
                                    <input type="hidden" name="slug" id="slug" size="20" maxlength="30" class="form-control input-sm" placeholder="Title" required>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-3">
                                    <div class="checkbox m-b-15">
                                        <label>
                                            <input type="checkbox" name="active" value="1" checked="checked">
                                            <i class="input-helper"></i>
                                            Content Aktif ?
                                        </label>
                                    </div>

                                    <div class="form-group">
                                        <div class="fg-line">
                                            <div class="select">
                                                <select class="chosen" data-placeholder="Pilih kategori..." name="kategori" required>
                                                    <option value=""></option>
                                                    @foreach(BlogCategories::where('active','=','1')->get() as $cat)
                                                    <option value="{{$cat->id}}">{{$cat->title}}</option>
                                                    @endforeach
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="fg-line">
                                            <textarea class="form-control" rows="5" placeholder="Tulis deskripsi singkat" name="deskripsi" required></textarea>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="fg-line">
                                            <input type="text" name="tags" class="form-control input-sm" placeholder="Tags... (Pisahkan dengan koma)" required>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <p class="c-black"><i>Upload Gambar</i></p>
                                        <div class="fileinput fileinput-new" data-provides="fileinput">
                                            <span class="btn btn-primary btn-file m-r-10">
                                                <span class="fileinput-new">Pilih Gambar</span>
                                                <span class="fileinput-exists">Ganti</span>
                                                <input type="file" name="images" accept="image/*" required>
                                            </span>
                                            <span class="fileinput-filename"></span>
                                            <a href="#" class="close fileinput-exists" data-dismiss="fileinput">&times;</a>
                                        </div>
                                    </div>
                                    
                                </div>

                                <div class="col-sm-9">
                                    <div class="form-group">
                                        <div class="fg-line">
                                            <textarea class="html-editor" id="summernote" name="body"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                {{ Form::close() }}

                </div>
            </section>

@stop

    @section('student_js')
        <script src="{{ URL::asset('assets/backend/vendors/bower_components/nouislider/distribute/jquery.nouislider.all.min.js') }}"></script>
        <script src="{{ URL::asset('assets/backend/vendors/summernote/dist/summernote-updated.min.js') }}"></script>

        <script src="{{ URL::asset('assets/backend/vendors/bower_components/chosen/chosen.jquery.min.js') }}"></script>
        <script src="{{ URL::asset('assets/backend/vendors/fileinput/fileinput.min.js') }}"></script>
        <script src="{{ URL::asset('assets/backend/vendors/bower_components/chosen/chosen.jquery.min.js') }}"></script>
        <script src="{{ URL::asset('assets/backend/vendors/farbtastic/farbtastic.min.js') }}"></script>

        <script type="text/javascript">
            $('#summernote').summernote({
              height: 350,
              toolbar: [
                ['style', ['style']],
                ['font', ['bold', 'italic', 'underline', 'clear']],
                ['fontname', ['fontname']],
                ['color', ['color']],
                ['para', ['ul', 'ol', 'paragraph']],
                ['height', ['height']],
                ['table', ['table']],
              ]
            });
        </script>
        <script type="text/javascript">
            $("#title").keyup(function(){
                    var Text = $(this).val();
                    Text = Text.toLowerCase();
                    Text = Text.replace(/[^a-zA-Z0-9]+/g,'-');
                    $("#slug").val(Text);        
            });
        </script>
    @endsection