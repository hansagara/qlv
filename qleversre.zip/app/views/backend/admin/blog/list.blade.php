@extends('backend/admin/layout')
    @section('title', 'Admin Blog')

    @section('css')
        <link href="{{ URL::asset('assets/backend/vendors/bootgrid/jquery.bootgrid.min.css') }}" rel="stylesheet">
    @endsection

@section('content')
    @include('backend.admin.inc.sidebar_left')
    
            <section id="content">
                <div class="container">
                    
                    <div class="card">
                        <div class="card-header">
                            <a href="{{url('admin/tambah/blog')}}" class="btn btn-primary btn-sm m-t-10">Tambah</a>
                        </div>

                        <div class="table-responsive">
                            <table id="data-table-basic" class="table table-striped">
                                <thead>
                                    <tr>
                                        <th data-column-id="id" data-type="numeric" data-identifier="true">No</th>
                                        <th data-column-id="show" data-formatter="link">Judul</th>
                                        <th data-column-id="aktif">kategori</th>
                                        <th data-column-id="received">Aktif</th>
                                        <th data-column-id="date">Pub Date</th>
                                        <th data-column-id="action" data-formatter="link2">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {{-- */$i=1;/* --}}
                                    @foreach(BlogArticles::with('bcat')->orderBy('id', 'desc')->get() as $blog)
                                    <tr>
                                        <td>{{ $i++ }}</td>
                                        <td><a href="#">{"url":"{{url('admin/edit/blog/'.$blog->id)}}","text":"{{Str::words($blog->title, 5)}}"}</a></td>
                                        <td>{{$blog->bcat->title}}</td>
                                        <td>
                                            @if($blog->active == '1')
                                            Ya
                                            @else
                                            Tidak
                                            @endif
                                        </td>
                                        <td>{{date('Y-M-d',strtotime($blog->created_at))}}</td>
                                        <td><a href="#">{"url":"{{url('admin/delete/blog/'.$blog->id)}}","text":"hapus"}</a></td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>

                </div>
            </section>

@stop

    @section('student_js')
        <script src="{{ URL::asset('assets/backend/vendors/bootgrid/jquery.bootgrid.updated.min.js') }}"></script>

        <script type="text/javascript">
            $(document).ready(function(){
                //Basic Example
                $("#data-table-basic").bootgrid({
                    css: {
                        icon: 'zmdi icon',
                        iconColumns: 'zmdi-view-module',
                        iconDown: 'zmdi-expand-more',
                        iconRefresh: 'zmdi-refresh',
                        iconUp: 'zmdi-expand-less'
                    },
                    formatters: {
                        "link": function(column, row) {
                            var json_data = JSON.parse(row.show);
                            return "<a href=\"" + json_data.url + "\">" + json_data.text + "</a>";
                        },
                        "link2": function(column, row) {
                            var json_data = JSON.parse(row.action);
                            return "<a href=\"" + json_data.url + "\">" + json_data.text + "</a>";
                        }
                    },
                });
                
            });
        </script>

    @endsection