@extends('backend/student/layout')

@section('title', 'Tanya Jawab')
@section('description', 'Qlevers adalah sebuah situs belajar dan tanya jawab online yang menghubungkan para pelajar di indonesia')
@section('keywords', 'Soal Matematika,Soal Fisika,Soal Kimia,Soal Biologi,Soal PPKN,Soal Pancasila,Soal Agama,Soal Psikologi,Soal Sejarah,Bahasa Indonesia, Bahasa Inggris, Bahasa English, Aljabar Linier,Bahasa Pemograman,Komputer,tkj')
@section('images', URL::asset('assets/frontend/img/qlevers-image.gif'))
@section('url', url('/'))

@section('student_css')

@endsection

@section('content')

            <aside id="s-main-menu" class="sidebar">
                <div class="col-md-12 hidden-sm hidden-xs">
                    <div class="card">
                        <a href="{{url('/')}}">
                            <img src="{{ URL::asset('assets/frontend/img/ads-qlevers.gif') }}" width="100%">
                        </a>
                    </div>
          
                    <div class="card">
                            <div class="card-header">
                                <h2>Mata Pelajaran</h2>
                            </div>
                            <div class="card-body card-padding">
                                <div class="pmo-contact">
                                    <ul>
                                        @foreach(Pelajaran::where('active','=','1')->get() as $mpel)
                                        <li class="ng-binding listside"><i class="zmdi zmdi-layers" style="color:#6cd6f5;"></i>
                                            <a href="{{url('/cari/pelajaran',$mpel->id)}}" style="color:#000;"> {{$mpel->title}}</a>
                                        </li>
                                        @endforeach
                                    </ul>
                                </div>
                            </div>
                            <a href="javascript::" class="list-group-item view-more moreside">
                                <i class="zmdi zmdi-long-arrow-right"></i> Load more
                            </a>
                    </div>
                </div>
            </aside>

            <section id="content">
                <div class="container">

                    <div class="card">
                        <div class="ms-user clearfix palette-Teal-400 bg" style="background:#6cd6f5;">
                            @if(Sentry::getUser()->avatar == '')
                                <img class="ava" data-name="{{Sentry::getUser()->email}}" alt=""/>
                            @else
                                {{ HTML::image(Sentry::getUser()->avatar,'',array('alt'=>'user profile image')) }}
                            @endif

                            @if(Sentry::getUser()->first_name == '')
                                <div>Signed in as <br/> {{Sentry::getUser()->email}}</div>
                            @else
                                <div>Signed in as <br/> {{Sentry::getUser()->first_name}}</div>
                            @endif
                        </div>

                        <div class="card-header">
                            <h1>Ayo tinggal satu langkah lagi...</h1>
                        </div>

                        <div class="card-body card-padding">

                        {{ Form::open(['url' => '/complete/form/student/'.Sentry::getUser()->id]) }}

                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="zmdi zmdi-account"></i></span>
                                        <div class="fg-line">
                                            <input type="text" class="form-control" placeholder="Nama Depan" name="first_name" value="{{Sentry::getUser()->first_name}}" required>
                                        </div>
                                    </div>
                                    <br/>
                                </div>
                        
                                <div class="col-sm-6">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="zmdi zmdi-account"></i></span>
                                        <div class="fg-line">
                                            <input type="text" class="form-control" placeholder="Nama Belakang" name="last_name" value="{{Sentry::getUser()->last_name}}">
                                        </div>
                                    </div>
                                    <br/>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="zmdi zmdi-city-alt"></i></span>
                                        <div class="fg-line">
                                            <select class=" form-control" name="id_jenjang" id="jenjang" required>
                                                @foreach(Jenjang::get() as $jn)
                                                <option value="{{$jn->id}}">{{$jn->title}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    <br/>
                                </div>
                        
                                <div class="col-sm-6">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="zmdi zmdi-city-alt"></i></span>
                                        <div class="fg-line">
                                            <select class=" form-control" id="kelas" name="id_kelas" required>
                                                <option>Pilih Kelas</option>
                                            </select>
                                        </div>
                                    </div>
                                    <br/>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="zmdi zmdi-account-box-mail"></i></span>
                                        <div class="fg-line">
                                            <input type="text" class="form-control" placeholder="Contact Number" name="email" value="{{Sentry::getUser()->email}}" disabled>
                                        </div>
                                    </div>
                                    <br/>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="input-group" style="float: right;">
                                        <div class="fg-line">
                                            <button class="btn btn-info btn-icon-text" type="submit">Simpan & Lanjutkan <i class="zmdi zmdi-mail-send"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        {{ Form::close() }}

                        </div>
                    </div>
                </div>
            </section>

@stop

@section('student_js')
    <link rel="stylesheet" href="{{ URL::asset('assets/socket/datepicker/themes/base/jquery.ui.all.css') }}">
    <script src="{{ URL::asset('assets/socket/datepicker/js/jquery-1.7.2.js') }}"></script>
    <script src="{{ URL::asset('assets/socket/datepicker/ui/jquery.ui.core.js') }}"></script>
    <script src="{{ URL::asset('assets/socket/datepicker/ui/jquery.ui.widget.js') }}"></script>
    <script src="{{ URL::asset('assets/socket/datepicker/ui/jquery.ui.datepicker.js') }}"></script>

    <script type="text/javascript">
        $('#jenjang').change(function(){
            $.getJSON("{{ url('/complete/register/kelas')}}", 
            { option: $(this).val() }, 
            function(data) {
                var model = $('#kelas');
                model.empty();
                $.each(data, function(index, element) {
                    model.append("<option value='"+element.id+"'>" + element.title + "</option>");
                });
            });
        });
    </script>

    <script type="text/javascript">
    $(function() {
        $( "#datepicker" ).datepicker({
            dateFormat: "dd/mm/yy",
            changeMonth: true,
            changeYear: true,
            yearRange: "1960:2016"
        });
    });
    </script>
@endsection