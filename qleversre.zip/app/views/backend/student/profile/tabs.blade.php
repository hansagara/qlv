							<ul class="tab-nav tn-justified">
                                <li class="active waves-effect"><a href="{{url('/student/profiles/'.Sentry::getUser()->id)}}">Tentang</a></li>
                                <li class="waves-effect"><a href="{{url('/student/profiles/media/'.Sentry::getUser()->id)}}">Media</a></li>
                                <li class="waves-effect"><a href="{{url('/student/profiles/history/ask/'.Sentry::getUser()->id)}}">History</a></li>
                            </ul>