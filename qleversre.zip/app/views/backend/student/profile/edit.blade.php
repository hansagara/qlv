@extends('backend/student/layout')

@section('title', 'Tanya Jawab')
@section('description', 'Qlevers adalah sebuah situs belajar dan tanya jawab online yang menghubungkan para pelajar di indonesia')
@section('keywords', 'Soal Matematika,Soal Fisika,Soal Kimia,Soal Biologi,Soal PPKN,Soal Pancasila,Soal Agama,Soal Psikologi,Soal Sejarah,Bahasa Indonesia, Bahasa Inggris, Bahasa English, Aljabar Linier,Bahasa Pemograman,Komputer,tkj')
@section('images', URL::asset('assets/frontend/img/qlevers-image.gif'))
@section('url', url('/'))

@section('student_css')

@endsection

@section('content')

            <aside id="s-main-menu" class="sidebar">
                <div class="col-md-12 hidden-sm hidden-xs">
                    <div class="card">
                        <a href="{{url('/')}}">
                            <img src="{{ URL::asset('assets/frontend/img/ads-qlevers.gif') }}" width="100%">
                        </a>
                    </div>
          
                    <div class="card">
                            <div class="card-header">
                                <h2>Mata Pelajaran</h2>
                            </div>
                            <div class="card-body card-padding">
                                <div class="pmo-contact">
                                    <ul>
                                        @foreach(Pelajaran::where('active','=','1')->get() as $mpel)
                                        <li class="ng-binding listside"><i class="zmdi zmdi-layers" style="color:#6cd6f5;"></i>
                                            <a href="{{url('/cari/pelajaran',$mpel->id)}}" style="color:#000;"> {{$mpel->title}}</a>
                                        </li>
                                        @endforeach
                                    </ul>
                                </div>
                            </div>
                            <a href="javascript::" class="list-group-item view-more moreside">
                                <i class="zmdi zmdi-long-arrow-right"></i> Load more
                            </a>
                    </div>
                </div>
            </aside>

            <section id="content">
                <div class="container">

                    <div class="card">
                        <div class="card-header">
                            <h2>Edit User <small>Untuk mengubah data kamu, silahkan isi form dibawah ini</small></h2>
                            @if (Session::has('flash_message'))
                                <div class="alert alert-success alert-dismissible" role="alert">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    {{ Session::get('flash_message') }}
                                </div>
                            @endif
                        </div>

                        <div class="card-body card-padding">

                        {{ Form::model($user, ['method' => 'PATCH', 'route' => ['student.profiles.update', $user->id]]) }}

                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="zmdi zmdi-account"></i></span>
                                        <div class="fg-line">
                                            {{ Form::text('first_name', null, ['class' => 'form-control']) }}
                                            {{ errors_for('first_name', $errors) }}
                                        </div>
                                    </div>
                                    <br/>
                                </div>
                        
                                <div class="col-sm-6">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="zmdi zmdi-account"></i></span>
                                        <div class="fg-line">
                                            {{ Form::text('last_name', null, ['class' => 'form-control']) }}
                                            {{ errors_for('last_name', $errors) }}
                                        </div>
                                    </div>
                                    <br/>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="zmdi zmdi-city-alt"></i></span>
                                        <div class="fg-line">
                                            <select class=" form-control" name="id_jenjang" id="jenjang" required>
                                                <option value="{{$user->id_jenjang}}">Pilih Jenjang</option>
                                                @foreach(Jenjang::get() as $jn)
                                                <option value="{{$jn->id}}">{{$jn->title}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>
                                    <br/>
                                </div>
                        
                                <div class="col-sm-6">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="zmdi zmdi-city-alt"></i></span>
                                        <div class="fg-line">
                                            <select class=" form-control" id="kelas" name="id_kelas" required>
                                                <option value="{{$user->id_kelas}}">Pilih Kelas</option>
                                            </select>
                                        </div>
                                    </div>
                                    <br/>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="zmdi zmdi-account-box-mail"></i></span>
                                        <div class="fg-line">
                                            {{ Form::email('email', null, ['class' => 'form-control','readonly']) }}
                                            {{ errors_for('email', $errors) }}
                                        </div>
                                    </div>
                                    <br/>
                                </div>

                                <div class="col-sm-6">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="zmdi zmdi-account"></i></span>
                                        <div class="fg-line">   
                                            {{ Form::text('no_contact', null, ['class' => 'form-control']) }}
                                            {{ errors_for('no_contact', $errors) }}
                                        </div>
                                    </div>
                                    <br/>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="zmdi zmdi-key"></i></span>
                                        <div class="fg-line">
                                            {{ Form::password('password', ['class' => 'form-control']) }}
                                            <p class="help-block">Leave password blank to NOT edit the password.</p>
                                            {{ errors_for('password', $errors) }}
                                        </div>
                                    </div>
                                    <br/>
                                </div>
                        
                                <div class="col-sm-6">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="zmdi zmdi-key"></i></span>
                                        <div class="fg-line">
                                            {{ Form::password('password_confirmation', ['class' => 'form-control'] )}}
                                        </div>
                                    </div>
                                    <br/>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="input-group" style="float: right;">
                                        <div class="fg-line">
                                            <button class="btn btn-info btn-icon-text" type="submit">Simpan & Tutup <i class="zmdi zmdi-mail-send"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        {{ Form::close() }}

                        </div>
                    </div>
                </div>
            </section>

@stop

@section('student_js')

    <script type="text/javascript">
        $('#jenjang').change(function(){
            $.getJSON("{{ url('/complete/register/kelas')}}", 
            { option: $(this).val() }, 
            function(data) {
                var model = $('#kelas');
                model.empty();
                $.each(data, function(index, element) {
                    model.append("<option value='"+element.id+"'>" + element.title + "</option>");
                });
            });
        });
    </script>
@endsection