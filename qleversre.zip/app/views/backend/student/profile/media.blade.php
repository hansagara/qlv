@extends('backend/student/layout')

@section('title', Sentry::getUser()->first_name.' '.Sentry::getUser()->last_name)
@section('description', Sentry::getUser()->first_name.' adalah member di qlevers.com')
@section('keywords', 'Soal Matematika,Soal Fisika,Soal Kimia,Soal Biologi,Soal PPKN,Soal Pancasila,Soal Agama,Soal Psikologi,Soal Sejarah,Bahasa Indonesia, Bahasa Inggris, Bahasa English, Aljabar Linier,Bahasa Pemograman,Komputer,tkj')
@section('images', URL::asset(Sentry::getUser()->avatar))
@section('url', url('/'))

@section('content')

            <!--
       		<aside id="s-main-menu" class="sidebar">
                <div class="col-md-12 hidden-sm hidden-xs">

                    <div class="card popular-post">
                    	<div class="card-header">
                                <h2>Messages</h2>
                            </div>
                            <div class="card-body">
                                @include('backend.student.profile.testimoni')
                            </div>
                        </div>

                </div>
            </aside>
            -->
            
            <section id="content">
                <div class="container">
                  
                    <div class="card" id="profile-main">
                        <div class="pm-overview" style="background: #fff;">
                            <div class="pmo-pic">
                                <div class="p-relative">
                                    <a href="">
                                    	@if(Sentry::getUser()->avatar == '')
				                            <img class="img-responsive ava" data-name="{{Sentry::getUser()->first_name}}" alt=""/>
				                        @else
				                            {{ HTML::image(Sentry::getUser()->avatar,'',array('alt'=>'user profile image','class'=>'img-responsive')) }}
				                        @endif
                                    </a>

                                    <div class="dropdown pmop-message">
                                        <a data-toggle="dropdown" href="" class="btn palette-White bg btn-float z-depth-1">
                                            <i class="zmdi zmdi-comment-text-alt"></i>
                                        </a>

                                        <div class="dropdown-menu">
                                            <textarea placeholder="Write something..."></textarea>
                                            <button class="btn bgm-green btn-float"><i class="zmdi zmdi-mail-send"></i></button>
                                        </div>
                                    </div>

                                    <a href="" class="pmop-edit">
                                        <i class="zmdi zmdi-camera"></i> <span class="hidden-xs">Update Profile Picture</span>
                                    </a>
                                </div>

                                <div class="pmo-stat">
                                    <h2 class="m-0 c-white">1562</h2>
                                    Total Rate
                                </div>
                            </div>
                        </div>

                        <div class="pm-body clearfix">
                            @include('backend.student.profile.tabs')

                            <div class="pmb-block clearfix photos">

                                <div class="lightbox">
	                                
	                                @foreach(AskActivy::with('ask')->where('active','=','1')->orderBy('id', 'DESC')->get() as $av)
	                                	@if($av->ask->id_user == Sentry::getUser()->id)

	                                		@if(file_exists($av->ask->files))
	                                			<div data-src="{{ URL::asset($av->ask->files) }}" class="col-md-3 col-sm-4 col-xs-6">
			                                        <div class="lightbox-item p-item">
			                                            <img src="{{ URL::asset($av->ask->files) }}" alt="" />
			                                        </div>
			                                    </div>
	                                        @else
	                                        @endif
	                                    
	                                    @else

	                                    @endif
	                                @endforeach

                                </div>

                                <div class="clearfix"></div>

                                <div class="load-more m-t-30">
                                    <a href=""><i class="zmdi zmdi-refresh-alt"></i> Load More...</a>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </section>
@endsection
