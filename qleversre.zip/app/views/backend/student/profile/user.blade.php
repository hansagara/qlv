@extends('backend/student/layout')

@section('title', $user->first_name.' '.$user->last_name)
@section('description', $user->first_name.' adalah member di qlevers.com')
@section('keywords', 'Soal Matematika,Soal Fisika,Soal Kimia,Soal Biologi,Soal PPKN,Soal Pancasila,Soal Agama,Soal Psikologi,Soal Sejarah,Bahasa Indonesia, Bahasa Inggris, Bahasa English, Aljabar Linier,Bahasa Pemograman,Komputer,tkj')
@section('images', URL::asset($user->avatar))
@section('url', url('/'))

@section('content')
        <!--
        <aside id="s-main-menu" class="sidebar">
                <div class="col-md-12 hidden-sm hidden-xs">

                    {{ Form::open(['url' => 'post/review', 'files' => true]) }}
                    
                        @if($user->id == Sentry::getUser()->id)
                        @else
                        <div class="card popular-post">
                            <div class="card-body card-padding">
                                <input type="hidden" name="from" value="{{Sentry::getUser()->id}}">
                                <input type="hidden" name="to" value="{{$user->id}}">
                                <textarea class="wp-text" name="body" data-auto-size placeholder="Tulis komentar disini..." required></textarea>
                            </div>
                            <ul class="list-unstyled clearfix wpb-actions">
                                <button type="submit" class="btn btn-primary btn-sm btn-icon"><i class="zmdi zmdi-check"></i></button>
                            </ul>
                        </div>
                        @endif
                    
                    {{ Form::close() }}

                    <div class="card popular-post">
                        <div class="card-body">
                                <div class="list-group lg-alt">
                                    <a href="" class="list-group-item media">
                                        <div class="pull-left">
                                            <img class="avatar-img ava" src="img/profile-pics/1.jpg" alt="">
                                        </div>

                                        <div class="media-body">
                                            <div class="lgi-heading">David Villa Jacobs</div>
                                            <small class="lgi-text">Sorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam mattis lobortis sapien non posuere</small>
                                        </div>
                                    </a>
                                    <a href="" class="list-group-item view-more">
                                        <i class="zmdi zmdi-long-arrow-right"></i> View all
                                    </a>
                                </div>
                        </div>
                    </div>

                </div>
            </aside>
        -->
        <section id="content">
                <div class="container">
                  
                    <div class="card" id="profile-main">
                        <div class="pm-overview" style="background: #fff;">
                            <div class="pmo-pic">
                                <div class="p-relative">
                                    <a href="">
                                    	@if($user->avatar == '')
				                            <img class="img-responsive ava" data-name="{{$user->first_name}}" alt=""/>
				                        @else
				                            {{ HTML::image($user->avatar,'',array('alt'=>'user profile image','class'=>'img-responsive')) }}
				                        @endif
                                    </a>

                                    <a href="" class="pmop-edit">
                                        <i class="zmdi zmdi-camera"></i> <span class="hidden-xs">Update Profile Picture</span>
                                    </a>
                                </div>

                                <div class="pmo-stat">
                                    <h2 class="m-0 c-white">{{Comment::where('id_user','=',$user->id)->sum('rating')}}</h2>
                                    Total Rate
                                </div>
                            </div>
                        </div>

                        <div class="pm-body clearfix">
                            @include('backend.student.profile.tabs')

                            <div class="pmb-block">
                                <div class="pmbb-header">
                                    <h2><i class="zmdi zmdi-account m-r-5"></i> Information</h2>
                                </div>
                                <div class="pmbb-body p-l-30">
                                    <div class="pmbb-view">
                                        <dl class="dl-horizontal">
                                            <dt>Full Name</dt>
                                            <dd>{{$user->first_name}} {{$user->last_name}}</dd>
                                        </dl>
                                        <dl class="dl-horizontal">
                                            <dt>Gender</dt>
                                            <dd>{{$user->gender}}</dd>
                                        </dl>
                                        <dl class="dl-horizontal">
                                            <dt>Birthday</dt>
                                            <dd>{{date('d-M-Y',strtotime($user->tgl_lahir))}}</dd>
                                        </dl>
                                        <dl class="dl-horizontal">
                                            <dt>Tingkat</dt>
                                            <dd>{{$user->id_jenjang}}</dd>
                                        </dl>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </section>

@endsection