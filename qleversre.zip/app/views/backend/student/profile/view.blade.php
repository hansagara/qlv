@extends('backend/student/layout')

@section('title', Sentry::getUser()->first_name.' '.Sentry::getUser()->last_name)
@section('description', Sentry::getUser()->first_name.' adalah member di qlevers.com')
@section('keywords', 'Soal Matematika,Soal Fisika,Soal Kimia,Soal Biologi,Soal PPKN,Soal Pancasila,Soal Agama,Soal Psikologi,Soal Sejarah,Bahasa Indonesia, Bahasa Inggris, Bahasa English, Aljabar Linier,Bahasa Pemograman,Komputer,tkj')
@section('images', URL::asset(Sentry::getUser()->avatar))
@section('url', url('/'))

@section('content')
    <!--
        <aside id="s-main-menu" class="sidebar">
                <div class="col-md-12 hidden-sm hidden-xs">

                    <div class="card popular-post">
                    	<div class="card-header">
                            <h2>Messages</h2>
                        </div>
                        <div class="card-body">
                            @include('backend.student.profile.testimoni')
                        </div>
                    </div>

                </div>
            </aside>
    -->
        <section id="content">
                <div class="container">
                  
                    <div class="card" id="profile-main">
                        <div class="pm-overview" style="background: #fff;">
                            <div class="pmo-pic">
                                <div class="p-relative">
                                    <a href="">
                                    	@if(Sentry::getUser()->avatar == '')
				                            <img class="img-responsive ava" data-name="{{Sentry::getUser()->first_name}}" alt=""/>
				                        @else
				                            {{ HTML::image(Sentry::getUser()->avatar,'',array('alt'=>'user profile image','class'=>'img-responsive')) }}
				                        @endif
                                    </a>

                                    <div class="dropdown pmop-message">
                                        <a data-toggle="dropdown" href="" class="btn palette-White bg btn-float z-depth-1">
                                            <i class="zmdi zmdi-comment-text-alt"></i>
                                        </a>

                                        <div class="dropdown-menu">
                                            <textarea placeholder="Write something..."></textarea>
                                            <button class="btn bgm-green btn-float"><i class="zmdi zmdi-mail-send"></i></button>
                                        </div>
                                    </div>

                                    <a href="" class="pmop-edit">
                                        <i class="zmdi zmdi-camera"></i> <span class="hidden-xs">Update Profile Picture</span>
                                    </a>
                                </div>

                                <div class="pmo-stat">
                                    <h2 class="m-0 c-white">0</h2>
                                    Total Rate
                                </div>
                            </div>
                        </div>

                        <div class="pm-body clearfix">
                            @include('backend.student.profile.tabs')

                            <div class="pmb-block">
                                <div class="pmbb-header">
                                    <h2><i class="zmdi zmdi-account m-r-5"></i> Information</h2>

                                    <ul class="actions">
                                        <li class="dropdown">
                                            <a href="" data-toggle="dropdown">
                                                <i class="zmdi zmdi-more-vert"></i>
                                            </a>

                                            <ul class="dropdown-menu dropdown-menu-right">
                                                <li>
                                                    <a href="{{url('/student/profiles/'.Sentry::getUser()->id.'/edit')}}">Edit</a>
                                                </li>
                                            </ul>
                                        </li>
                                    </ul>
                                </div>
                                <div class="pmbb-body p-l-30">
                                    <div class="pmbb-view">
                                        <dl class="dl-horizontal">
                                            <dt>Full Name</dt>
                                            <dd>{{Sentry::getUser()->first_name}} {{Sentry::getUser()->last_name}}</dd>
                                        </dl>
                                        <dl class="dl-horizontal">
                                            <dt>No Hp</dt>
                                            <dd>{{Sentry::getUser()->no_contact}}</dd>
                                        </dl>
                                        <dl class="dl-horizontal">
                                            <dt>Tingkat</dt>
                                            <dd>{{Sentry::getUser()->id_jenjang}}</dd>
                                        </dl>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </section>

@endsection