                                <div class="list-group lg-alt">
                                    <a href="" class="list-group-item media">
                                        <div class="pull-left">
                                            <img class="avatar-img ava" src="img/profile-pics/1.jpg" alt="">
                                        </div>

                                        <div class="media-body">
                                            <div class="lgi-heading">David Villa Jacobs</div>
                                            <small class="lgi-text">Sorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam mattis lobortis sapien non posuere</small>
                                        </div>
                                    </a>

                                    <a href="" class="list-group-item media">
                                        <div class="pull-left">
                                            <img class="avatar-img ava" src="img/profile-pics/5.jpg" alt="">
                                        </div>
                                        <div class="media-body">
                                            <div class="lgi-heading">Candice Barnes</div>
                                            <small class="lgi-text">Quisque non tortor ultricies, posuere elit id, lacinia purus curabitur.</small>
                                        </div>
                                    </a>

                                    <a href="" class="list-group-item media">
                                        <div class="pull-left">
                                            <img class="avatar-img ava" src="img/profile-pics/3.jpg" alt="">
                                        </div>
                                        <div class="media-body">
                                            <div class="lgi-heading">Jeannette Lawson</div>
                                            <small class="lgi-text">Donec congue tempus ligula, varius hendrerit mi hendrerit sit amet. Duis ac quam sit amet leo feugiat iaculis</small>
                                        </div>
                                    </a>

                                    <a href="" class="list-group-item media">
                                        <div class="pull-left">
                                            <img class="avatar-img ava" src="img/profile-pics/4.jpg" alt="">
                                        </div>
                                        <div class="media-body">
                                            <div class="lgi-heading">Darla Mckinney</div>
                                            <small class="lgi-text">Duis tincidunt augue nec sem dignissim scelerisque. Vestibulum rhoncus sapien sed nulla aliquam lacinia</small>
                                        </div>
                                    </a>

                                    <a href="" class="list-group-item media">
                                        <div class="pull-left">
                                            <img class="avatar-img" src="img/profile-pics/2.jpg" alt="">
                                        </div>
                                        <div class="media-body">
                                            <div class="lgi-heading">Rudolph Perez</div>
                                            <small class="lgi-text">Phasellus a ullamcorper lectus, sit amet viverra quam. In luctus tortor vel nulla pharetra bibendum</small>
                                        </div>
                                    </a>

                                    <a href="" class="list-group-item view-more">
                                        <i class="zmdi zmdi-long-arrow-right"></i> View all
                                    </a>
                                </div>