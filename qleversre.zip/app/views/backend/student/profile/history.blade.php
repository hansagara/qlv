@extends('backend/student/layout')

@section('title', Sentry::getUser()->first_name.' '.Sentry::getUser()->last_name)
@section('description', Sentry::getUser()->first_name.' adalah member di qlevers.com')
@section('keywords', 'Soal Matematika,Soal Fisika,Soal Kimia,Soal Biologi,Soal PPKN,Soal Pancasila,Soal Agama,Soal Psikologi,Soal Sejarah,Bahasa Indonesia, Bahasa Inggris, Bahasa English, Aljabar Linier,Bahasa Pemograman,Komputer,tkj')
@section('images', URL::asset(Sentry::getUser()->avatar))
@section('url', url('/'))
@section('css')
    <link href="{{ URL::asset('assets/backend/css/history.css') }}" rel="stylesheet">
@endsection
@section('content')

<section id="content">
                <div class="container">
                  
                    <div class="card" id="profile-main">
                        <div class="pm-overview" style="background: #fff;">
                            <div class="pmo-pic">
                                <div class="p-relative">
                                    <a href="">
                                    	@if(Sentry::getUser()->avatar == '')
				                            <img class="img-responsive ava" data-name="{{Sentry::getUser()->first_name}}" alt=""/>
				                        @else
				                            {{ HTML::image(Sentry::getUser()->avatar,'',array('alt'=>'user profile image','class'=>'img-responsive')) }}
				                        @endif
                                    </a>

                                    <div class="dropdown pmop-message">
                                        <a data-toggle="dropdown" href="" class="btn palette-White bg btn-float z-depth-1">
                                            <i class="zmdi zmdi-comment-text-alt"></i>
                                        </a>

                                        <div class="dropdown-menu">
                                            <textarea placeholder="Write something..."></textarea>
                                            <button class="btn bgm-green btn-float"><i class="zmdi zmdi-mail-send"></i></button>
                                        </div>
                                    </div>

                                    <a href="" class="pmop-edit">
                                        <i class="zmdi zmdi-camera"></i> <span class="hidden-xs">Update Profile Picture</span>
                                    </a>
                                </div>

                                <div class="pmo-stat">
                                    <h2 class="m-0 c-white">1562</h2>
                                    Total Rate
                                </div>
                            </div>
                        </div>

                        <div class="pm-body clearfix">
                            @include('backend.student.profile.tabs')

                            <div class="pmb-block clearfix photos">

				    			<div class="qa-message-list" id="wallmessages">
				    				@foreach($paginateask = AskActivy::with('ask')->where('active','=','1')->orderBy('id', 'DESC')->paginate(10) as $av)
	                                	@if($av->ask->id_user == Sentry::getUser()->id)
					    				<div class="message-item" id="m16">
											<div class="message-inner">
												<div class="message-head clearfix">
													<div class="avatar pull-left">
														@if($av->ask->user->avatar == '')
			                                                <img class="image-profile ava" data-name="{{$av->ask->user->first_name}}" alt=""/>
			                                            @else
			                                                {{ HTML::image($av->ask->user->avatar,'',array('class'=>'image-profile','alt'=>'$av->ask->user->first_name')) }}
			                                            @endif
													</div>
													<div class="user-detail">
														<h5 class="handle">{{$av->ask->user->first_name}} </h5>
														<div class="post-meta">
															<div class="asker-meta">
																<span class="qa-message-what"></span>
																<span class="qa-message-when">
																	<span class="qa-message-when-data">{{$av->ask->mapel->title}} - <span data-livestamp="{{$av->created_at}}"></span>
																	</span>
																</span>
															</div>
														</div>
													</div>
												</div>
												<a href="{{url('/tugas/'.$av->id)}}" style="color:#000;">
												<div class="qa-message-content">
													{{nl2br($av->ask->body)}}
												</div>
												</a>
											</div>
										</div>
										@else

	                                    @endif
	                                @endforeach
								</div>

                                <div class="clearfix"></div>

                                <div class="load-more m-t-30">
                                    <a href=""><i class="zmdi zmdi-refresh-alt"></i> Load More...</a>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </section>
@endsection