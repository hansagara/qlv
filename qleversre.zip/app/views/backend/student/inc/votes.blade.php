<div class="card">
<div class="alert alert-info" role="alert" style="background: #0c7695;">Bantu kami untuk menjadi lebih baik <a data-toggle="modal" href="#votes" class="btn btn-default"> Berikan Penilaian</a></div>

                       <div class="modal fade" id="votes" data-backdrop="static" data-keyboard="false" tabindex="-1" role="dialog" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header" style="background: #0c7695;">
                                            <h4 class="modal-title" style="color: #fff;">Beri Kami Penilaian</h4>
                                        </div>
                               			{{ Form::open(['url' => 'post/votes', 'files' => true]) }}
	                                        <div class="modal-body">
	                                        	<br>
                                        			<input type="hidden" name="user" value="{{Sentry::getUser()->id}}">

					                                <div class="m-b-25">
					                                    <p class="f-500 m-b-15 c-black">1. Apakah qlevers sangat membantu kamu?</p>
					                                    <div class="radio m-b-15">
							                                <label>
							                                    <input type="radio" name="votes2" value="1" required>
							                                    <i class="input-helper"></i>
							                                    Ya
							                                </label>
							                            </div>
							                            <div class="radio m-b-15">
							                                <label>
							                                    <input type="radio" name="votes2" value="2" required>
							                                    <i class="input-helper"></i>
							                                    Tidak
							                                </label>
							                            </div>
					                                </div>

					                                <div class="m-b-25">
					                                    <p class="f-500 m-b-15 c-black">2. Ada masalah yang kamu temui saat menggunakan qlevers?</p>
					                                    <div class="radio m-b-15">
							                                <label>
							                                    <input type="radio" name="votes3" value="1" required>
							                                    <i class="input-helper"></i>
							                                    Ya
							                                </label>
							                            </div>
							                            <div class="radio m-b-15">
							                                <label>
							                                    <input type="radio" name="votes3" value="2" required>
							                                    <i class="input-helper"></i>
							                                    Tidak
							                                </label>
							                            </div>
					                                </div>

						                            <div class="form-group">
						                            	<label class="c-black f-500 m-b-20">3. Beri kami masukan</label>
						                                <div class="fg-line">
						                                    <textarea class="form-control" name="body" rows="5" placeholder="Tulis pesan kamu disini...."></textarea>
						                                </div>
						                            </div>

	                                        </div>
	                                        <div class="modal-footer">
	                                            <button type="submit" class="btn btn-link">Simpan dan tutup</button>
	                                            <button type="button" class="btn btn-link" data-dismiss="modal">Tutup</button>
	                                        </div>
                               			{{ Form::close() }}
                                    </div>
                                </div>
                            </div>
</div>