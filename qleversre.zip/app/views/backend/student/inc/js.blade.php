        <!-- Javascript Libraries -->
        <script src="{{ URL::asset('assets/backend/vendors/bower_components/jquery/dist/jquery.min.js') }}"></script>
        <script src="{{ URL::asset('assets/backend/vendors/bower_components/bootstrap/dist/js/bootstrap.min.js') }}"></script>
        <script src="{{ URL::asset('assets/backend/vendors/bower_components/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.concat.min.js') }}"></script>
        <script src="{{ URL::asset('assets/backend/vendors/bower_components/Waves/dist/waves.min.js') }}"></script>
        <script src="{{ URL::asset('assets/backend/vendors/bootstrap-growl/bootstrap-growl.min.js') }}"></script>
        <script src="{{ URL::asset('assets/backend/vendors/bower_components/lightgallery/dist/js/lightgallery-all.min.js') }}"></script>
        <script src="{{ URL::asset('assets/backend/vendors/bower_components/autosize/dist/autosize.min.js') }}"></script>

        <script src="{{ URL::asset('assets/backend/js/functions.js') }}"></script>
        <script src="{{ URL::asset('assets/backend/js/actions.js') }}"></script>
        <script src="{{ URL::asset('assets/backend/js/demo.js') }}"></script>

        <script src="{{ URL::asset('assets/socket/moment.js') }}"></script>
        <script src="{{ URL::asset('assets/socket/livestamp.js') }}"></script>
        
        <script src="{{ URL::asset('assets/backend/js/initial.js') }}"></script>
        <script>
                $('.ava').initial(); 
        </script> 
        
        <script type="text/javascript">
            $(".listside").hide();
                $(".listside").slice(0, 5).show();

                $(".moreside").click(function(){
                    var showing = $(".listside:visible").length;
                    $(".listside").slice(showing - 1, showing + 5).show();
            });
        </script>

        @yield('student_js')