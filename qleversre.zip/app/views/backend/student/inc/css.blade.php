        <meta name="token" content="{{ Session::token() }}">

        <!-- Vendor CSS -->
        <link href="{{ URL::asset('assets/backend/vendors/bower_components/animate.css/animate.min.css') }}" rel="stylesheet">
        <link href="{{ URL::asset('assets/backend/vendors/bower_components/material-design-iconic-font/dist/css/material-design-iconic-font.min.css') }}" rel="stylesheet">
        <link href="{{ URL::asset('assets/backend/vendors/vendors/bower_components/malihu-custom-scrollbar-plugin/jquery.mCustomScrollbar.min.css') }}" rel="stylesheet">
        <link href="{{ URL::asset('assets/backend/vendors/bower_components/lightgallery/dist/css/lightgallery.min.css') }}" rel="stylesheet">
        <link href="{{ URL::asset('assets/backend/vendors/bower_components/google-material-color/dist/palette.css') }}" rel="stylesheet">
        @yield('css')

        <!-- CSS -->
        <link href="{{ URL::asset('assets/backend/css/app.min.1.css') }}" rel="stylesheet">
        <link href="{{ URL::asset('assets/backend/css/app.min.2.css') }}" rel="stylesheet">
        <link href="{{ URL::asset('assets/backend/css/badge.css') }}" rel="stylesheet">
        @yield('student_css')
