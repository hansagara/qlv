        <header id="header" class="media" style="position:relative; background-color: #fdc210;">

            <div class="pull-left h-logo">
                <a href="{{url('/')}}" class="hidden-xs">
                    <img src="{{ URL::asset('assets/frontend/img/logo1.png') }}" width="70%">
                    <!--
                    <small style="padding-top:5px;">alfa testing</small>
                    Qlevers
                    <small>solution education</small>
                    -->
                </a>
                <div class="menu-collapse" data-user-alert="sua-pelajaran" data-ma-action="sidebar-open" data-ma-target="user-alerts">
                    <div class="mc-wrap">
                        <a href="#sua-pelajaran" data-toggle="tab">
                        <div class="mcw-line top palette-White bg"></div>
                        <div class="mcw-line center palette-White bg"></div>
                        <div class="mcw-line bottom palette-White bg"></div>
                        </a>
                    </div>
                </div>
            </div>

            <ul class="pull-right h-menu">

                <li class="hm-search-trigger">
                    <a href="" data-ma-action="search-open">
                        <i class="hm-icon zmdi zmdi-search"></i>
                    </a>
                </li>

                <li class="dropdown h-apps">
                    <a href="{{url('/')}}">
                        <i class="hm-icon zmdi zmdi-home"></i>
                    </a>
                </li>

                <li class="dropdown hidden-xs" data-user-alert="sua-notifications" data-ma-action="sidebar-open" data-ma-target="user-alerts">
                    @if($notif = Notification::where('id_to','=',Sentry::getUser()->id)->where('active','=','1')->count() >= 1 )
                    <a class="sua-notifications" href="#sua-notifications" data-toggle="tab">
                        <i class="hm-icon zmdi zmdi-notifications" style="color:#198484;"></i>
                        <md-badge class="md-primary">{{Notification::where('id_to','=',Sentry::getUser()->id)->where('active','=','1')->count()}}</md-badge>
                    </a>
                    @else
                    <a class="sua-notifications" href="#sua-notifications" data-toggle="tab">
                        <i class="hm-icon zmdi zmdi-notifications"></i>
                    </a>
                    @endif
                </li>

                <li class="hm-alerts" data-user-alert="sua-notifications" data-ma-action="sidebar-open" data-ma-target="user-alerts">
                    @if($notif = Notification::where('id_to','=',Sentry::getUser()->id)->where('active','=','1')->count() >= 1 )
                    <a class="sua-notifications" href="#sua-notifications" data-toggle="tab">
                        <i class="hm-icon zmdi zmdi-notifications" style="color:#198484;"></i>
                        <md-badge class="md-primary">{{Notification::where('id_to','=',Sentry::getUser()->id)->where('active','=','1')->count()}}</md-badge>
                    </a>
                    @else
                    <a class="sua-notifications" href="#sua-notifications" data-toggle="tab">
                        <i class="hm-icon zmdi zmdi-notifications"></i>
                    </a>
                    @endif
                </li>

                <!--
                <li class="dropdown hidden-xs hidden-sm h-apps" data-user-alert="sua-messages" data-ma-action="sidebar-open" data-ma-target="user-email">
                    <a class="sua-notifications" href="#sua-messages" data-toggle="tab">
                        <i class="hm-icon zmdi zmdi-email"></i>
                    </a>
                </li>
                -->
                
                <li class="dropdown hm-profile">
                    <a data-toggle="dropdown" href="">
                        @if(Sentry::getUser()->avatar == '')
                            <img class="ava" data-name="{{Sentry::getUser()->first_name}}" alt=""/>
                        @else
                            {{ HTML::image(Sentry::getUser()->avatar,'',array('alt'=>'user profile image')) }}
                        @endif
                    </a>

                    <ul class="dropdown-menu pull-right dm-icon">
                        <li>
                            <a href="{{url('/student/profiles/'.Sentry::getUser()->id)}}"><i class="zmdi zmdi-account"></i> My Profile</a>
                        </li>
                        <li>
                            <a href="{{url('/student/profiles/'.Sentry::getUser()->id.'/edit')}}"><i class="zmdi zmdi-settings"></i> Settings</a>
                        </li>
                        <li>
                            <a href="{{url('/logout')}}"><i class="zmdi zmdi-time-restore"></i> Logout</a>
                        </li>
                    </ul>
                </li>

            </ul>

            <div class="media-body h-search">
                {{ Form::open(['url' => 'cari/tugas','method'=>'GET','class'=>'p-relative','files' => true]) }}
                    <input type="text" class="hs-input" name="keyword" placeholder="Cari tugas atau pertanyaan disini...">
                    <i class="zmdi zmdi-search hs-reset" data-ma-action="search-clear"></i>
                {{ Form::close() }}
            </div>

        </header>