<div class="" style="margin-bottom: 20px;">
	<a href="{{url('/sayembara')}}">
    	<img src="{{ URL::asset('assets/frontend/img/promo.png') }}" width="100%">
    </a>
</div>