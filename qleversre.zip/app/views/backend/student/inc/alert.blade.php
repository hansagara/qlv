            <aside id="s-user-alerts" class="sidebar">
                <!--
                <ul class="tab-nav tn-justified tn-icon m-t-10" data-tab-color="teal">
                    <li><a class="sua-notifications" href="#sua-notifications" data-toggle="tab"><i class="zmdi zmdi-notifications"></i></a></li>
                    <li><a class="sua-messages" href="#sua-messages" data-toggle="tab"></a></li>
                </ul>
                -->
                <div class="tab-content">
                    <div class="tab-pane fade" id="sua-notifications">
                        <ul class="sua-menu list-inline list-unstyled palette-Light-Blue bg">
                            <li><a href="javascript::"><i class="zmdi zmdi-check-all"></i>Notifikasi</a></li>
                            <li><a href="javascript::"><i class="zmdi zmdi-long-arrow-tab"></i> Lihat semua</a></li>
                            <li><a href="" data-ma-action="sidebar-close"><i class="zmdi zmdi-close"></i> Tutup</a></li>
                        </ul>

                        <div class="list-group lg-alt c-overflow">
                        @foreach(Notification::with('ask')->with('comment')->with('from')->where('id_to','=',Sentry::getUser()->id)->where('active','=','1')->paginate(10) as $notifuser )
                            {{ Form::open(['url' => '/tugas/notif/'.$notifuser->id]) }}
                            <input type="hidden" name="idnotif" value="{{$notifuser->comment->ask->id}}">
                            <a href="javascript::" onclick="$(this).closest('form').submit()" class="list-group-item media">
                                <div class="pull-left">
                                    @if($notifuser->from->avatar == '')
                                        <img class="avatar-img ava" data-name="{{$notifuser->from->first_name}}" alt=""/>
                                    @else
                                        {{ HTML::image($av->ask->user->avatar,'',array('class'=>'avatar-img','alt'=>'$av->ask->user->first_name')) }}
                                    @endif
                                </div>

                                <div class="media-body">
                                    <div class="lgi-heading">{{$notifuser->from->first_name}}</div>
                                    <small class="lgi-text"><i class="zmdi zmdi-time"></i> Comment at <span data-livestamp="{{$notifuser->created_at}}"></span></small>
                                    <small>Mengomentari pertanyaan anda...</small>
                                </div>
                            </a>
                            {{ Form::close() }}
                        @endforeach
                        </div>
                    </div>

                    <div class="tab-pane fade" id="sua-pelajaran">
                        <ul class="sua-menu list-inline list-unstyled palette-Light-Blue bg">
                            <li><a href="javascript::"><i class="zmdi zmdi-check-all"></i>Pelajaran</a></li>
                            <li><a href="" data-ma-action="sidebar-close"><i class="zmdi zmdi-close"></i> Tutup</a></li>
                        </ul>

                        <div class="list-group lg-alt c-overflow">
                            <div class="card-body card-padding">
                                <div class="pmo-contact">
                                    <ul>
                                        @foreach(Pelajaran::where('active','=','1')->get() as $mpel1)
                                        <li class="ng-binding"><i class="zmdi zmdi-layers" style="color:#6cd6f5;"></i>
                                            <a href="{{url('/cari/pelajaran',$mpel1->id)}}" style="color:#000;"> {{$mpel1->title}}</a>
                                        </li>
                                        @endforeach
                                    </ul>
                                </div>
                            </div>

                        </div>

                    </div>

                </div>
            </aside>