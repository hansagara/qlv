        <aside id="s-main-menu" class="sidebar">
                <div class="col-md-12 hidden-sm hidden-xs">

                        <div class="card popular-post">
                            <div class="card-header ch-img" style="background-color: #fdc210;">
                                <span class="media">
                                    <div class="pull-left">
                                        @if(Sentry::getUser()->avatar == '')
                                            <img class="avatar-img ava" data-name="{{Sentry::getUser()->first_name}}" alt=""/>
                                        @else
                                            {{ HTML::image(Sentry::getUser()->avatar,'',array('class'=>'avatar-img','alt'=>'user profile image')) }}
                                        @endif
                                    </div>
                                    <div class="media-body">
                                        <h2><small>{{Sentry::getUser()->first_name}}</small></h2>
                                    </div>
                                </span>
                            </div>
                            <!--
                            <div class="card-body p-10">
                                <div class="media-body">
                                    
                                </div>
                            </div>-->
                        </div>
                        <!--
                        <div class="card c-dark profile-view palette-Blue bg">
                            <div class="card-header text-center palette-Blue-400 bg">
                                @if(Sentry::getUser()->avatar == '')
                                    <img class="pv-img ava" data-name="{{Sentry::getUser()->first_name}}" alt=""/>
                                @else
                                    {{ HTML::image(Sentry::getUser()->avatar,'',array('class'=>'pv-img','alt'=>'user profile image')) }}
                                @endif
                                <h2 class="m-t-10">{{Sentry::getUser()->first_name}}</h2>

                                <ul class="actions a-alt">
                                    <li class="dropdown">
                                        <a href="" data-toggle="dropdown">
                                            <i class="zmdi zmdi-more-vert"></i>
                                        </a>

                                        <ul class="dropdown-menu dropdown-menu-right">
                                            <li>
                                                <a href="">Edit</a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>

                            <div class="card-body p-30">
                                <div class="list-group lg-alt">
                                    <div class="media">
                                        <div class="pull-left">
                                            <i class="pvb-icon zmdi zmdi-phone"></i>
                                        </div>
                                        <div class="media-body">
                                            <div class="f-15">011 55694785</div>
                                            <small>POINT</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        -->
                    <div class="card">
                            <div class="card-header">
                                <h2>Mata Pelajaran</h2>
                            </div>
                            <div class="card-body card-padding">
                                <div class="pmo-contact">
                                    <ul>
                                        @foreach(Pelajaran::where('active','=','1')->get() as $mpel)
                                        <li class="ng-binding listside"><i class="zmdi zmdi-layers" style="color:#6cd6f5;"></i>
                                            <a href="{{url('/cari/pelajaran',$mpel->id)}}" style="color:#000;"> {{$mpel->title}}</a>
                                        </li>
                                        @endforeach
                                    </ul>
                                </div>
                            </div>
                            <a href="javascript::" class="list-group-item view-more moreside">
                                <i class="zmdi zmdi-long-arrow-right"></i> Load more
                            </a>
                    </div>
                </div>
            </aside>