                        <div class="card">
                                <div class="card-header">
                                    <h2><i class="zmdi zmdi-thumb-up"></i> SISWA TERBAIK</h2>
                                </div>

                                <div class="list-group lg-alt">
                                    @foreach(User::paginate(7) as $user)
                                        @if(Comment::where('id_user','=',$user->id)->sum('rating') > 0)
                                            @if ($user->inGroup(Sentry::findGroupByName('Users')))
                                            <a href="" class="list-group-item media">
                                                <div class="pull-left">
                                                    @if($user->avatar == '')
                                                        <img class="avatar-img a-lg ava" data-name="{{$user->first_name}}" alt=""/>
                                                    @else
                                                        {{ HTML::image($user->avatar,'',array('class'=>'avatar-img a-lg','alt'=>'$user->first_name')) }}
                                                    @endif
                                                </div>

                                                <div class="media-body">
                                                    <div class="lgi-heading">{{$user->first_name}} {{$user->last_name}}</div>
                                                    <small class="lgi-text">Rating {{Comment::where('id_user','=',$user->id)->sum('rating')}}</small>
                                                </div>
                                            </a>
                                            @endif
                                        @endif
                                    @endforeach
                                </div>

                                <a href="{{url('/top/rank')}}" class="list-group-item view-more">
                                    <i class="zmdi zmdi-long-arrow-right"></i> View all
                                </a>
                            </div>

                            <div class="card">
                                <footer id="footer">
                                    Copyright &copy; {{ date("Y") }} Qlevers
                                </footer>
                            </div>