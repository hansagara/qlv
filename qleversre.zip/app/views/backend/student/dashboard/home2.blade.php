@extends('backend/student/layout')

@section('title', 'Tanya Jawab')
@section('description', 'Qlevers adalah sebuah situs belajar dan tanya jawab online yang menghubungkan para pelajar di indonesia')
@section('keywords', 'Soal Matematika,Soal Fisika,Soal Kimia,Soal Biologi,Soal PPKN,Soal Pancasila,Soal Agama,Soal Psikologi,Soal Sejarah,Bahasa Indonesia, Bahasa Inggris, Bahasa English, Aljabar Linier,Bahasa Pemograman,Komputer,tkj')
@section('images', URL::asset('assets/frontend/img/qlevers-image.gif'))
@section('url', url('/'))

@section('css')
    <link href="{{ URL::asset('assets/backend/js/select/bootstrap-select.min.css') }}" rel="stylesheet">
    <link href="http://jcrop-cdn.tapmodo.com/v0.9.12/css/jquery.Jcrop.min.css" rel="stylesheet">
    <style type="text/css">
         #blah {
            width: 100%;
          }
    </style>
@endsection

@section('content')

        @include('backend.student.inc.sidebar_left')
            
            <section id="content">
                <div class="container">
                    <div class="row">
                        <div class="col-md-8">
                            @include('backend.student.inc.sayembara')
                            <div class="card wall-posting">

                                {{ Form::open(['url' => 'post/ask', 'files' => true,'id'=>'form1','runat'=>'server']) }}
                                    <div class="card-body card-padding">
                                        <input type="hidden" name="user" value="{{Sentry::getUser()->id}}">
                                        <textarea class="wp-text" name="pertanyaan" data-auto-size placeholder="Tulis pertanyaan disini..." required></textarea>
                                        <div class="fg-line">
                                            <select class="selectpicker" data-live-search="true" data-placeholder="Pilih mata pelajaran..." name="mapel">
                                                <option selected="true" disabled="disabled">Pilih mata pelajaran...</option>
                                                <optgroup label="Mata Pelajaran">
                                                    @foreach(Pelajaran::where('active','=','1')->get() as $mapel)
                                                    <option value="{{$mapel->id}}">{{$mapel->title}}</option>
                                                    @endforeach
                                                </optgroup>
                                            </select>
                                        </div>

                                        <div class="tab-content p-0">
                                            <div class="wp-media tab-pane" id="wpm-image">
                                                
                                                <div class="fileinput fileinput-new" data-provides="fileinput">
                                                    <img id="blah" class="crop" src="#" alt="" />
                                                    <div>
                                                        <span class="btn btn-info btn-file">
                                                            <span class="fileinput-new">Select image</span>
                                                            <input type="file" name="images" id="imgInp">

                                                        </span>
                                                    </div>
                                                </div>
                                                <input type="text" id="x" name="x"/>
                                                <input type="text" id="y" name="y"/>
                                                <input type="text" id="w" name="w"/>
                                                <input type="text" id="h" name="h"/>
                                            </div>
                                        </div>
                                    </div>

                                    <ul class="list-unstyled clearfix wpb-actions">
                                        <li class="wpba-attrs">
                                            <ul class="list-unstyled list-inline">
                                                <li><a data-wpba="image" data-toggle="tab" href="" data-target="#wpm-image"><i class="zmdi zmdi-image"></i></a></li>
                                            </ul>
                                        </li>
                                        <button type="submit" class="btn btn-primary btn-sm btn-icon"><i class="zmdi zmdi-check"></i></button>
                                    </ul>
                                {{ Form::close() }}
                            </div>

                            @foreach($paginateask = AskActivy::with('ask')->where('active','=','1')->orderBy('id', 'DESC')->get() as $av)
                            <div class="card listitem">
                                <div class="card-header">
                                    <div class="media">
                                        <div class="pull-left">
                                            @if($av->ask->user->avatar == '')
                                                <img class="avatar-img a-lg ava" data-name="{{$av->ask->user->first_name}}" alt=""/>
                                            @else
                                                {{ HTML::image($av->ask->user->avatar,'',array('class'=>'avatar-img a-lg','alt'=>'$av->ask->user->first_name')) }}
                                            @endif
                                        </div>
                                        <ul class="actions">
                                            <li class="dropdown">
                                                <a href="" data-toggle="dropdown">
                                                    <i class="zmdi zmdi-more-vert"></i>
                                                </a>
                                                <ul class="dropdown-menu dropdown-menu-right">
                                                    <li>
                                                        <a href="">Report</a>
                                                    </li>
                                                    @if($av->ask->id_user == Sentry::getUser()->id)
                                                    <li>
                                                        <a href="">Edit</a>
                                                    </li>
                                                    @else
                                                    @endif
                                                </ul>
                                            </li>
                                        </ul>

                                        <div class="media-body m-t-5">
                                            <h2>
                                                <a href="{{url('student/user',$av->ask->id_user)}}" style="color:#000;">
                                                {{$av->ask->user->first_name}} 
                                                </a>
                                                <small>{{$av->ask->mapel->title}} - <i class="zmdi zmdi-time"></i> Posted on <span data-livestamp="{{$av->created_at}}"></span></small>
                                            </h2>
                                        </div>
                                    </div>
                                </div>

                                <div class="card-body card-padding">
                                    <a href="{{url('/tugas/'.$av->id)}}" style="color:#000;">
                                        <p>
                                            {{nl2br($av->ask->body)}}
                                        </p>
                                        @if(file_exists($av->ask->files))
                                        <div class="wall-img-preview lightbox clearfix">
                                            <div class="wip-item" data-src="{{ URL::asset($av->ask->files) }}" style="background-image: url({{ URL::asset($av->ask->files) }});">
                                                <div class="lightbox-item"></div>
                                            </div>
                                        </div>
                                        @else
                                        @endif
                                    </a>

                                    <ul class="wall-attrs clearfix list-inline list-unstyled">
                                        <li class="">
                                            <a href="{{url('/cari/pelajaran',$av->ask->mapel->id)}}"><span class="active"><i class="zmdi zmdi-refresh-sync"></i> Pertanyaan sejenis</span></a>
                                        </li>
                                        <li class="wa-users">
                                            <a href="{{url('/tugas/'.$av->id)}}">
                                                <span>{{Comment::with('ask')->with('user')->where('id_ask','=',$av->id_ask)->where('active','=','1')->count() }} orang menjawab</span> 
                                            </a>
                                            @foreach($comquery = Comment::with('ask')->with('user')->where('id_ask','=',$av->id_ask)->where('active','=','1')->get() as $commentsum)

                                            @if($commentsum->id_user == $av->ask->id_user)
                                            @else
                                            <a href="{{url('student/user',$commentsum->id_user)}}">
                                                @if($commentsum->ask->user->avatar == '')
                                                    <img class="ava" data-name="{{$commentsum->user->first_name}}" title="{{$commentsum->user->first_name}}"/>
                                                @else
                                                    {{ HTML::image($commentsum->user->avatar,'',array('alt'=>'$commentsum->user->first_name')) }}
                                                @endif
                                            </a>
                                            @endif
                                            @endforeach
                                        </li>
                                    </ul>
                                </div>

                                <div class="wall-comment-list">
                                    <!-- Comment form -->
                                    <div class="wcl-form">
                                        <a href="{{url('/tugas/'.$av->id)}}">
                                        <div class="wc-comment">
                                            <div class="wcc-inner wcc-toggle">
                                                Tulis jawaban kamu...
                                            </div>
                                        </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            @endforeach

                            <div class="load-more more">
                                <a href="javascript::"><i class="zmdi zmdi-refresh-alt"></i> Load More...</a>
                            </div>
                    
                    </div>

                        <div class="col-md-4 hidden-sm hidden-xs">
                            @include('backend.student.inc.sidebar_right')
                        </div>

                    </div>
                </div>
            </section>

@stop

@section('student_js')
<script src="{{ URL::asset('assets/backend/js/select/bootstrap-select.min.js') }}"></script>

<script src="{{ URL::asset('assets/backend/vendors/fileinput/fileinput.min.js') }}"></script>
<script type="text/javascript">
    $(".listitem").hide();
        $(".listitem").slice(0, 10).show();

        $(".more").click(function(){
            var showing = $(".listitem:visible").length;
            $(".listitem").slice(showing - 1, showing + 10).show();
    });
</script>

<script src="http://jcrop-cdn.tapmodo.com/v0.9.12/js/jquery.Jcrop.min.js"></script>
<script type="text/javascript">
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function (e) {
                $('#blah').attr('src', e.target.result);
                $('.crop').Jcrop({
                    aspectRatio: 0,
                    onChange: updateCoords,
                    onSelect: updateCoords
                });
            }
            
            reader.readAsDataURL(input.files[0]);
        }
    }
    
    $("#imgInp").change(function(){
        console.log(this);
        readURL(this);
    });

  function updateCoords(c)
  {
    console.log(c);
    $('#x').val(c.x);
    $('#y').val(c.y);
    $('#w').val(c.w);
    $('#h').val(c.h);
  };
</script>
@endsection