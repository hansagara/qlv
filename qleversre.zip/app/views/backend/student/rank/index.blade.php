@extends('backend/student/layout')

@section('title', 'Tanya Jawab')
@section('description', 'Qlevers adalah sebuah situs belajar dan tanya jawab online yang menghubungkan para pelajar di indonesia')
@section('keywords', 'Soal Matematika,Soal Fisika,Soal Kimia,Soal Biologi,Soal PPKN,Soal Pancasila,Soal Agama,Soal Psikologi,Soal Sejarah,Bahasa Indonesia, Bahasa Inggris, Bahasa English, Aljabar Linier,Bahasa Pemograman,Komputer,tkj')
@section('images', URL::asset('assets/frontend/img/qlevers-image.gif'))
@section('url', url('/'))

@section('content')

            <aside id="s-main-menu" class="sidebar">
                <div class="col-md-12 hidden-sm hidden-xs">
                <!--
                    <div class="card">
                        <a href="{{url('/pages/login')}}">
                            <img src="{{ URL::asset('assets/frontend/img/ads-qlevers.gif') }}" width="100%">
                        </a>
                    </div>
                -->
                    <div class="card">
                            <div class="card-header">
                                <h2>Mata Pelajaran</h2>
                            </div>
                            <div class="card-body card-padding">
                                <div class="pmo-contact">
                                    <ul>
                                        @foreach(Pelajaran::paginate(5) as $mpel)
                                        <li class="ng-binding"><i class="zmdi zmdi-layers" style="color:#6cd6f5;"></i><a href="" style="color:#000;"> {{$mpel->title}}</a></li>
                                        @endforeach
                                    </ul>
                                </div>
                            </div>
                            <a href="" class="list-group-item view-more">
                                <i class="zmdi zmdi-long-arrow-right"></i> View all
                            </a>
                    </div>
                </div>
            </aside>

            <section id="content">
                <div class="container">

                    <div class="card">
                        <div class="action-header palette-Blue bg clearfix" style="background:#fdc210;">
                            <div class="ah-label hidden-xs palette-White text">TOP Rank Students</div>
                            <!--
                            <div class="ah-search">
                                <input type="text" placeholder="Start typing..." class="ahs-input">

                                <i class="ah-search-close zmdi zmdi-long-arrow-left" data-ma-action="ah-search-close"></i>
                            </div>

                            <ul class="ah-actions actions a-alt">
                                <li>
                                    <a href="" class="ah-search-trigger" data-ma-action="ah-search-open">
                                        <i class="zmdi zmdi-search"></i>
                                    </a>
                                </li>

                            </ul>
                            -->
                        </div>
                        <div class="card-body card-padding">

                            <div class="contacts clearfix row">
                            @foreach(User::paginate(7) as $user)
                                @if(Comment::where('id_user','=',$user->id)->sum('rating') > 0)
                                    @if ($user->inGroup(Sentry::findGroupByName('Users')))
                                <div class="col-md-2 col-sm-4 col-xs-6">
                                    <div class="c-item">
                                        <a href="javascript::" class="ci-avatar">
                                            @if($user->avatar == '')
                                                <img class="ava" data-name="{{$user->first_name}}" alt=""/>
                                            @else
                                                {{ HTML::image($user->avatar,'',array('class'=>'','alt'=>'$user->first_name')) }}
                                            @endif
                                        </a>

                                        <div class="c-info">
                                            <strong>{{$user->first_name}} {{$user->last_name}}</strong>
                                            <small>Point {{Comment::where('id_user','=',$user->id)->sum('rating')}}</small>
                                        </div>
                                    </div>
                                </div>
                                    @endif
                                @endif
                            @endforeach
                            </div>

                        </div>
                    </div>
                </div>
            </section>

@stop

@section('student_js')


@endsection