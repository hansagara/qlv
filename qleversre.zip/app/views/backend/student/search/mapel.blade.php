@extends('backend/student/layout')

@section('title', '')
@section('description', 'Qlevers adalah sebuah situs belajar dan tanya jawab online yang menghubungkan para pelajar di indonesia')
@section('keywords', 'Soal Matematika,Soal Fisika,Soal Kimia,Soal Biologi,Soal PPKN,Soal Pancasila,Soal Agama,Soal Psikologi,Soal Sejarah,Bahasa Indonesia, Bahasa Inggris, Bahasa English, Aljabar Linier,Bahasa Pemograman,Komputer,tkj')
@section('images', URL::asset('assets/frontend/img/qlevers-image.gif'))
@section('url', url('/'))

@section('css')

@endsection

@section('content')

            <aside id="s-main-menu" class="sidebar">
                <div class="col-md-12 hidden-sm hidden-xs">
                    <div class="card">
                        <a href="{{url('/pages/login')}}">
                            <img src="{{ URL::asset('assets/frontend/img/ads-qlevers.gif') }}" width="100%">
                        </a>
                    </div>
          
                    <div class="card">
                            <div class="card-header">
                                <h2>Mata Pelajaran</h2>
                            </div>
                            <div class="card-body card-padding">
                                <div class="pmo-contact">
                                    <ul>
                                        @foreach(Pelajaran::where('active','=','1')->get() as $mpel)
                                        <li class="ng-binding listside"><i class="zmdi zmdi-layers" style="color:#6cd6f5;"></i>
                                            <a href="{{url('/cari/pelajaran',$mpel->id)}}" style="color:#000;"> {{$mpel->title}}</a>
                                        </li>
                                        @endforeach
                                    </ul>
                                </div>
                            </div>
                            <a href="javascript::" class="list-group-item view-more moreside">
                                <i class="zmdi zmdi-long-arrow-right"></i> Load more
                            </a>
                    </div>
                </div>
            </aside>

            <section id="content">
                <div class="container">
                    <div class="row">
                        <div class="col-md-8">

                        <div id="result">
                            @foreach(Ask::with('user')->where('active','=','1')->orderBy('id', 'DESC')->where('id_pelajaran','=',$idmapel)->get() as $av)

                            @if($av->user->id_kelas == Sentry::getUser()->id_kelas)
                            <div class="card">
                                <div class="card-header">
                                    <div class="media">
                                        <div class="pull-left">
                                            @if($av->user->avatar == '')
                                                <img class="avatar-img a-lg ava" data-name="{{$av->user->first_name}}" alt=""/>
                                            @else
                                                {{ HTML::image($av->user->avatar,'',array('class'=>'avatar-img a-lg','alt'=>'$av->user->first_name')) }}
                                            @endif
                                        </div>
                                        <ul class="actions">
                                            <li class="dropdown">
                                                <a href="" data-toggle="dropdown">
                                                    <i class="zmdi zmdi-more-vert"></i>
                                                </a>
                                                <ul class="dropdown-menu dropdown-menu-right">
                                                    <li>
                                                        <a href="">Cari Pertanyaan Sejenis</a>
                                                    </li>
                                                    <li>
                                                        <a href="">Laporkan</a>
                                                    </li>
                                                </ul>
                                            </li>
                                        </ul>

                                        <div class="media-body m-t-5">
                                            <h2>
                                                {{$av->user->first_name}} 
                                                <small>{{$av->mapel->title}} - <i class="zmdi zmdi-time"></i> Posted on <span data-livestamp="{{$av->created_at}}"></span></small>
                                            </h2>
                                        </div>
                                    </div>
                                </div>

                                <div class="card-body card-padding">
                                    <p>
                                        <a href="{{url('/tugas/'.$av->id)}}" style="font-size:18px;color:#000;">
                                        {{nl2br($av->body)}}
                                        </a>
                                    </p>

                                    @if($av->files = '')
                                        <div class="wall-img-preview lightbox clearfix">
                                            <div class="wip-item" data-src="{{ URL::asset('assets/backend/img/headers/4.png') }}" style="background-image: url({{ URL::asset('assets/backend/img/headers/4.png') }});">
                                                <div class="lightbox-item"></div>
                                            </div>
                                        </div>
                                    @else

                                    @endif

                                    <ul class="wall-attrs clearfix list-inline list-unstyled">
                                        <li class="wa-users">
                                            @foreach($comquery = Comment::with('user')->where('id_ask','=',$av->id)->where('active','=','1')->get() as $commentsum)

                                            @if($commentsum->id_user == $av->id_user)
                                            @else
                                            <a href="{{url('student/user',$commentsum->id_user)}}">
                                                @if($commentsum->user->avatar == '')
                                                    <img class="ava" data-name="{{$commentsum->user->first_name}}" title="{{$commentsum->user->first_name}}"/>
                                                @else
                                                    {{ HTML::image($commentsum->user->avatar,'',array('alt'=>'$commentsum->user->first_name')) }}
                                                @endif
                                            </a>
                                            @endif
                                            @endforeach
                                        </li>
                                    </ul>
                                </div>

                                <div class="wall-comment-list">
                                    <!-- Comment form -->
                                    <div class="wcl-form">
                                        <div class="wc-comment">
                                            <div class="wcc-inner wcc-toggle">
                                                Write Something...
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            @endif

                            @endforeach
                        </div>

                            <div class="load-more">
                                <a href="#"><i class="zmdi zmdi-refresh-alt"></i> Load More...</a>
                            </div>
                    
                    </div>

                        <div class="col-md-4 hidden-sm hidden-xs">
                            <div class="card">
                                <div class="card-header ch-alt">
                                    <small>Filter pencarian</small>
                                </div>

                                <div class="card-body card-padding">
                                    <div class="form-group fg-float m-b-30">
                                        <div class="fg-line">
                                            <input type="email" class="form-control input-sm" value="">
                                            <label class="fg-label">Keyword</label>
                                        </div>
                                    </div>

                                    <div class="form-group fg-float m-b-30">
                                        <div class="fg-line">
                                            <select class="chosen" data-placeholder="Pilih mata pelajaran...">
                                                <option></option>
                                                @foreach(Pelajaran::paginate(5) as $sidepel)
                                                    <option value="{{$sidepel->id}}">{{$sidepel->title}}</option>
                                                @endforeach
                                            </select>
                                        </div>
                                    </div>


                                    <div class="clearfix"></div>

                                    <div class="m-t-20">
                                        <button class="btn btn-info">Filter</button>
                                    </div>
                                </div>
                            </div>

                            @include('backend.student.inc.sidebar_right')
                        </div>

                    </div>
                </div>
            </section>

@stop

@section('student_js')

@endsection