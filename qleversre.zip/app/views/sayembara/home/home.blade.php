@extends('sayembara/index')

@section('content')
<!-- MAIN -->
<main>
    <div class="container">
        <div class="row">

            <!-- ARTICLES -->
            <div class="col-lg-12 col-xs-12">
                <section class="articles">
                
                    <div class="row">
                        <div class="col-xs-12">
                            <section class="category-title">
                                <h4 style="color: #d1d1d1;">Soal Terbaru</h4>
                            </section>
                        </div>
                    </div>

                    <div class="row">
                        @foreach(Sayembara::where('active','=','1')->with('mapel')->get() as $soal)
                        <div class="col-lg-8 col-xs-12">
                            <article class="blue-article">
                                <div class="articles-header">
                                    <time datetime="2016-10-11"><span data-livestamp="{{$soal->created_at}}"></span></time>
                                    <span class="articles-header-tag-blue">New</span>
                                    <span class="articles-header-category"><a href="#" class="blue" title="">{{$soal->mapel->title}}</a></span>
                                </div>
                                <div class="articles-content">
                                    <iframe class="vimeo-movie" width="100%" height="315" src="{{$soal->files}}" frameborder="0" allowfullscreen></iframe>
                                    <p>
                                        {{$soal->body}}
                                    </p>
                                </div>

                                <div class="articles-footer" style="margin-bottom: -50px;">
                                    <a href="#" class="light-link" title=""><i class="fa fa-comments-o"></i> {{SayembaraComment::where('active','=','1')->where('id_sayembara','=',$soal->id)->count()}} Jawaban</a>
                                </div>

                                <div class="articles-footer post">
                                    <div class="post-footer">
                                        {{ Form::open(['url' => 'post/jawaban/sayembara', 'files' => true]) }}
                                        <input type="hidden" name="id_sayembara" value="{{$soal->id}}">
                                        <input type="hidden" name="user" value="{{Sentry::getUser()->id}}">
                                        <div class="input-group"> 
                                            <input class="form-control" placeholder="Tulis jawaban kamu disini" type="text" name="body">
                                            <span class="input-group-addon" style="background-color: #fff; border:0px; margin: -10px; margin-top: 15px;">
                                                <button type="submit" class="btn btn-info btn-sm"><i class="fa fa-edit"></i> Post</button>
                                            </span>
                                        </div>
                                        {{ Form::close() }}

                                        <ul class="comments-list">
                                            @foreach(SayembaraComment::where('active','=','1')->where('id_sayembara','=',$soal->id)->with('sayembara')->with('user')->get() as $jawab)
                                            <li class="comment">
                                                <a class="pull-left" href="#">
                                                    @if(Sentry::getUser()->avatar == '')
                                                        <img class="avatar ava" data-name="{{$jawab->user->first_name}}" alt=""/>
                                                    @else
                                                        {{ HTML::image($jawab->user->avatar,'',array('class'=>'avatar','alt'=>'user profile image')) }}
                                                    @endif
                                                </a>
                                                <div class="comment-body">
                                                    <div class="comment-heading">
                                                        <h4 class="user">{{$jawab->user->first_name}}</h4>
                                                        <h5 class="time"><span data-livestamp="{{$jawab->created_at}}"></span></h5>
                                                    </div>
                                                    <p>{{$jawab->body}}</p>
                                                </div>
                                            </li>
                                            @endforeach
                                        </ul>

                                    </div>
                                </div>

                            </article>
                        </div>
                        @endforeach

                        <div class="col-lg-4 col-xs-12">
                            <aside class="author">
                                @if(Sentry::getUser()->avatar == '')
                                    <img class="ava" data-name="{{Sentry::getUser()->first_name}}" alt="" data-rjs="2"/>
                                @else
                                    {{ HTML::image(Sentry::getUser()->avatar,'',array('data-rjs'=>'2','alt'=>'user profile image')) }}
                                @endif
                                <h2>{{Sentry::getUser()->first_name}}</h2>
                                <span class="author-info">Pelajar</span>
                                <br/>
                            </aside>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-xs-12">
                            <section class="category-title">
                                <h4 style="color: #d1d1d1;">Soal Terjawab</h4>
                                <span>0 Soal</span>
                            </section>
                        </div>
                    </div>

                    <!--
                    <div class="row">
                        <div class="col-lg-6 col-xs-12">
                            <article class="blue-article">
                                <div class="articles-header">
                                    <time datetime="2016-10-11">12 hours ago</time>
                                    <span class="articles-header-tag-blue">Hot</span>
                                    <span class="articles-header-category"><a href="#" class="blue" title="">CSS</a></span>
                                </div>
                                <div class="articles-content">
                                    <h1><a href="blog_post.html" title="">10 Interview</a></h1>
                                    <p>
                                        I was young, single, and freshly employed to direct National Journal’s Presentation
                                        Center, a searchable library of white-label
                                        PowerPoint presentations on political and policy developments. By day, I led a team of
                                        fellows in creating data
                                        visualizations...
                                    </p>
                                </div>
                                <div class="articles-footer">
                                    <ul class="articles-footer-info">
                                        <li><a href="#" class="light-link" title=""><i class="pe-7s-comment"></i> 7 Response</a>
                                        </li>
                                        <li><a href="#" class="light-link" title=""><i class="pe-7s-like"></i> 1221</a></li>
                                    </ul>
                                    <a title="" class="btn" href="blog_post.html">Read more</a>

                                </div>
                            </article>
                        </div>
                        <div class="col-lg-6 col-xs-12">
                            <article class="blue-article">
                                <div class="articles-header">
                                    <time datetime="2016-10-11">12 hours ago</time>
                                    <span class="articles-header-tag-blue">Hot</span>
                                    <span class="articles-header-category"><a href="#" class="blue" title="">CSS</a></span>
                                </div>
                                <div class="articles-content">
                                    <h1><a href="blog_post.html" title="">10 Interview</a></h1>
                                    <p>
                                        I was young, single, and freshly employed to direct National Journal’s Presentation
                                        Center, a searchable library of white-label
                                        PowerPoint presentations on political and policy developments. By day, I led a team of
                                        fellows in creating data
                                        visualizations...
                                    </p>
                                </div>
                                <div class="articles-footer">
                                    <ul class="articles-footer-info">
                                        <li><a href="#" class="light-link" title=""><i class="pe-7s-comment"></i> 7 Response</a>
                                        </li>
                                        <li><a href="#" class="light-link" title=""><i class="pe-7s-like"></i> 1221</a></li>
                                    </ul>
                                    <a title="" class="btn" href="blog_post.html">Read more</a>

                                </div>
                            </article>
                        </div>
                    </div>
                    -->

                </section>
            </div>

        </div>
    </div>
</main>
<!-- end MAIN -->
@stop
