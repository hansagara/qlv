<!doctype html>
<html lang="en">
<head>
    <!-- GENERAL -->
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Qlevers - Sayembara</title>

@include('sayembara.inc.css')

</head>
<body>

@include('sayembara.inc.menu')

@yield('content')


<!-- FOOTER -->
@include('sayembara.inc.footer')

<!-- end FOOTER -->

<!-- EXTERNAL JAVASCRIPT -->
@include('sayembara.inc.js')

</body>
</html>