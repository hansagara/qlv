<script src="{{ URL::asset('assets/sayembara/js/jquery-1.12.0.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/sayembara/js/tether.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/sayembara/js/bootstrap.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/sayembara/js/retina.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/sayembara/js/owl.carousel.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/sayembara/js/webfont.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('assets/sayembara/js/scripts.js') }}" type="text/javascript"></script>
        <script src="{{ URL::asset('assets/socket/moment.js') }}"></script>
        <script src="{{ URL::asset('assets/socket/livestamp.js') }}"></script>

        <script src="{{ URL::asset('assets/backend/js/initial.js') }}"></script>
        <script>
                $('.ava').initial(); 
        </script> 
<!-- MY JAVASCRIPT -->
