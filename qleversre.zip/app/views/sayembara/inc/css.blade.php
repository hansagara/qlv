    <!-- EXTERNAL CSS -->
	<link rel="stylesheet" type="text/css" href="{{ asset('assets/sayembara/css/bootstrap.css') }}">		
	<link rel="stylesheet" type="text/css" href="{{ asset('assets/sayembara/css/Pe-icon-7-stroke.css') }}">		
	<link rel="stylesheet" type="text/css" href="{{ asset('assets/sayembara/css/font-awesome.min.css') }}">		
	<link rel="stylesheet" type="text/css" href="{{ asset('assets/sayembara/css/social-icons.css') }}">		
	<link rel="stylesheet" type="text/css" href="{{ asset('assets/sayembara/css/owl.carousel.css') }}">		
	<link rel="stylesheet" type="text/css" href="{{ asset('assets/sayembara/css/owl.theme.css') }}">		
	<link rel="stylesheet" type="text/css" href="{{ asset('assets/sayembara/css/main.css?v1.1') }}">		
	<link rel="stylesheet" type="text/css" href="{{ asset('assets/sayembara/css/comment.css') }}">		
