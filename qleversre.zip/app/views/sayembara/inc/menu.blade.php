<!-- HEADER -->
<header class="navbar-fixed-top" style="background-color: #fdc210;">
    <div class="container">
        <div class="row">

            <!-- HEADER TOP -->
            <div class="col-lg-12">
                <div class="header-top">
                    <div class="header-top-logo">
                        <a href="{{url('/')}}" title="Logo"><img src="{{ URL::asset('assets/frontend/img/logo1.png') }}" alt="Dblog Logo" data-rjs="2" width="45%" style="float: left;"></a>
                    </div>
                </div>
            </div>
            <!-- end HEADER TOP -->

            <!-- HEADER NAVIGATION 
            <div class="col-lg-12">
                <nav class="header-nav">
                    <ul>
                        <li class="active"><a href="{{url('/sayembara')}}" title="Start page">New</a></li>
                        <li><a href="#" title="About me">Matematika</a></li>
                        <li><a href="#" title="My projects">Fisika</a></li>
                        <li><a href="#" title="Contact me">Ekonomi</a></li>
                        <li><a href="#" title="Contact me">Kimia</a></li>
                        <li><a href="#" title="Contact me">B.Inggris</a></li>
                        <li><a href="#" title="Contact me">Biologi</a></li>
                    </ul>
                </nav>
            </div>
            -->
        </div>
        <!-- end HEADER NAVIGATION -->

    </div>
</header>

<!-- end HEADER -->
<!-- MOBILE NAVIGATION -->

<nav class="mobile-nav header-nav">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <!-- Auto Copy Header Navigation -->
            </div>
        </div>
    </div>
</nav>