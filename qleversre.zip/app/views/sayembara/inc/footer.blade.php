<footer>
    <!-- COPYRIGHT -->
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <div class="copyright">
                    <p class="font-primary">&copy; Copyright © 2015 | <a href="#" title="" class="black">PT Qlevers Lab Media</a> . All
                        Rights Reserved.</p>
                </div>
            </div>
        </div>
    </div>
    <!-- end COPYRIHT -->
</footer>