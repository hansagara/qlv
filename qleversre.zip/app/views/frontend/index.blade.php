<!DOCTYPE html>
<html lang="en">

	<head>
		<!-- Meta -->
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1"> 
		<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
		<!-- SITE TITLE -->
		<title>Qlevers - Semua Belajar, Semua Pintar</title>			
		<!-- Latest Bootstrap min CSS -->
		@include('frontend.inc.css')
   		@include('ga')

	</head>
	
    <body data-spy="scroll" data-offset="80">

		<!-- START PRELOADER -->
		<div class="preloader">
			<div class="status">
				<div class="status-mes"></div>
			</div>
		</div>
		<!-- END PRELOADER -->
		
		<!-- START NAVBAR -->
		<div class="navbar navbar-default navbar-fixed-top menu-top">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a href="{{url('/')}}" class="navbar-brand"><img src="{{ URL::asset('assets/frontend/img/logo1.png') }}" alt="logo"></a>
				</div>
				<div class="navbar-collapse collapse">
					<nav>
						<ul class="nav navbar-nav navbar-right">
							@foreach(Menu::where('icon','=','1')->where('active','=','1')->get() as $m)
                            <li><a class="page-scroll" href="{{url('/pages/'.$m->id.'/'.date('Y-m-d',strtotime($m->created_at)).'/'.$m->slug)}}">{{$m->title}}</a></li>
                            @endforeach
							<li><a class="page-scroll" href="javascript::" data-toggle="modal" data-target="#mylogin">Login</a></li>
							<li><a class="page-scroll" href="{{url('/pages/register')}}">Register</a></li>
						</ul>
					</nav>
				</div> 
			</div><!--- END CONTAINER -->
		</div> 
		<!-- END NAVBAR -->	

			@yield('content')
		
		<!-- START CONTACT FORM -->
		
		<!-- START ADDRESS -->
		<section class="our-address section-padding" style="background-color: #eee;">
			<div class="container">
				<div class="row text-center">			
					<div class="col-md-4 col-sm-4 col-xs-12">
						<div class="single_address">
							<i class="fa fa-map-marker"></i>
							<h4>Our Location</h4>
							<p>
								Epicentrum Walk Office Suites South 529A, Jakarta Selatan
							</p>
						</div>
					</div><!-- END COL -->
					<div class="col-md-4 col-sm-4 col-xs-12">
						<div class="single_address">
							<i class="fa fa-phone"></i>
							<h4>Telephone</h4>
							<p>(021) 568 2703</p>
						</div>
					</div><!-- END COL -->
					<div class="col-md-4 col-sm-4 col-xs-12">
						<div class="single_address">
							<i class="fa fa-envelope-o"></i>
							<h4>Send email</h4>
							<p>
								cs@qlevers.com
							</p>
						</div>
					</div><!-- END COL -->
				</div><!-- END ROW -->						
			</div><!--- END CONTAINER -->	
		</section>
		<!-- END ADDRESS -->
		
		<!-- START FOOTER -->
		<div class="footer">
			<div class="container">
				<div class="row">					
					<div class="col-md-6 col-sm-6 col-xs-12 wow zoomIn">
						<div class="copyright">
							<p>Copyright &copy; 2015 | PT Qlevers Lab Media All Rights Reserved.</p>
						</div><!--- END FOOTER COPYRIGHT -->
					</div><!--- END COL -->		
					<div class="col-md-6 col-sm-6 col-xs-12 wow zoomIn">
						<div class="footer_social pull-right">
							<ul>
								<li><a class="f_facebook" href="https://web.facebook.com/Qlevers-Indonesia-1609830095988645/?fref=ts" target="blank"><i class="fa fa-facebook"></i></a></li>
								<li><a class="f_twitter" href="https://twitter.com/_qlevers" target="blank"><i class="fa fa-twitter"></i></a></li>
								<li><a class="f_google" href="https://plus.google.com/+Bootsnipp-page" target="blank"><i class="fa fa-google-plus"></i></a></li>
								<li><a class="f_youtube" href="#index.html" target="blank"><i class="fa fa-youtube"></i></a></li>
							</ul>
						</div>
					</div><!--- END COL -->			
				</div><!--- END ROW -->				
			</div><!--- END CONTAINER -->
		</div>

		<div class="modal fade" id="mylogin" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		  <div class="modal-dialog" role="document">
		    <div class="modal-content" style="background-color: #fff;">
		      <div class="modal-header" style="background-color: #FEC20F;">
		        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true" style="color: #000;">&times;</span></button>
		        <h4 class="modal-title" id="myModalLabel" style="color: #000;">Login</h4>
		      </div>
		      <div class="modal-body text-left">

		      	<div class="row">					
					<div class="col-md-6 col-sm-6 col-xs-12 wow" style="border-right: 1px solid #eee;">
                        {{ Form::open(['route' => 'sessions.store']) }}
				        <div class="form-group">
			                <label for="exampleInputEmail1">Email address</label>
			                <input type="email" class="form-control" name="email" id="exampleInputEmail1" placeholder="Enter email">
                            {{ errors_for('email', $errors) }}
			            </div>
			            <div class="form-group">
			                <label for="exampleInputPassword1">Password</label>
			                <input type="password" class="form-control" name="password" id="exampleInputPassword1" placeholder="Password">
                            {{ errors_for('password', $errors) }}
			            </div>
			            <div class="checkbox">
			                <label>
                              {{ Form::checkbox('remember', 'remember') }}
			                  Remember
			                </label>
			            </div>
				        <div class="form-group">
		        			<button type="submit" class="btn btn-primary">Login</button>
				        </div>
                        {{ Form::close() }}
		            </div>
					<div class="col-md-6 col-sm-6 col-xs-12 wow zoomIn" >
						<div class="form-group">
			                <label for="exampleInputEmail1">Login Menggunakan</label>
							<a href="{{ URL::to('auth/facebook') }}" class="btn btn-block btn-social btn-facebook">
						        <i class="fa fa-facebook"></i> Login with Facebook
						    </a>
						    <a href="{{ URL::to('auth/google') }}" class="btn btn-block btn-social btn-google-plus">
						        <i class="fa fa-google-plus"></i> Login with Google
						    </a>
					    </div>
					    <div class="form-group">
			                <small>Tidak bisa login? silahkan klik <a href="{{url('pages/forgot_password')}}">Lupa Password</a></small><br>
			                <small>Atau Belum Punya Akun? <a href="{{url('pages/register')}}">Register</a></small>
			            </div>
					</div>
	            </div>

		      </div>
		    </div>
		  </div>
		</div>
		<!-- END FOOTER -->		
		@include('frontend.inc.js')

    </body>
</html>