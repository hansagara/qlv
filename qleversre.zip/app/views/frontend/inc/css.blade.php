		<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
		<link rel="stylesheet" type="text/css" href="{{ asset('assets/frontend/bootstrap/css/bootstrap.min.css') }}">		
		<!-- Google Font -->
		<!-- Font Awesome CSS -->
		<link rel="stylesheet" type="text/css" href="{{ asset('assets/frontend/css/font-awesome.min.css') }}">
		<!--- owl carousel Css-->
		<link rel="stylesheet" type="text/css" href="{{ asset('assets/frontend/owlcarousel/css/owl.carousel.css') }}">
		<link rel="stylesheet" type="text/css" href="{{ asset('assets/frontend/owlcarousel/css/owl.theme.css') }}">				
		<!-- animate CSS -->		
		<link rel="stylesheet" type="text/css" href="{{ asset('assets/frontend/css/animate.css') }}">	
		<!-- jquery carousel-3d default CSS -->	
		<link rel="stylesheet" type="text/css" href="{{ asset('assets/frontend/css/jquery.carousel-3d.default.css') }}">			
		<!-- Style CSS -->
		<link rel="stylesheet" type="text/css" href="{{ asset('assets/frontend/css/style.css') }}">	