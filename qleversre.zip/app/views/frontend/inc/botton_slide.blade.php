						<div class="home_btn">
							<a href="javascript::" data-toggle="modal" data-target="#mylogin" class="app-btn wow bounceIn" data-wow-delay=".6s" ><i class="fa fa-user"></i> LOG IN</a>
							<a href="{{url('pages/register')}}" class="app-btn wow bounceIn" data-wow-delay=".8s" ><i class="fa fa-users"></i> REGISTER</a>
						</div>