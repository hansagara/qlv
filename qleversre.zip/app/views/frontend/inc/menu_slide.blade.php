				<div class="row text-center" style="margin-top: 50px;">
				  	<div class="col-md-4 col-sm-4 col-xs-12">
				  		<a href="{{url('pages/1/2016-09-11/tentang-qlevers')}}">
							<h4 style="color: #fff;"><i class="fa fa-check"></i> Tentang Kami</h4>
						</a>
					</div><!-- END COL-->
					<div class="col-md-4 col-sm-4 col-xs-12">
						<a href="{{url('pages/3/2016-09-10/cara-kerja-qlevers')}}">
							<h4 style="color: #fff;"><i class="fa fa-check"></i> Cara Kerja</h4>
						</a>
					</div><!-- END COL-->
					<div class="col-md-4 col-sm-4 col-xs-12">
						<a href="{{url('pages/4/2016-09-10/faq-qlevers')}}">
							<h4 style="color: #fff;"><i class="fa fa-check"></i> FAQ</h4>
						</a>
					</div><!-- END COL-->		  
				</div><!--- END ROW -->