		<script src="{{ URL::asset('assets/frontend/js/jquery-1.12.4.min.js') }}" type="text/javascript"></script>
		<script src="{{ URL::asset('assets/frontend/bootstrap/js/bootstrap.min.js') }}" type="text/javascript"></script>
		<script src="{{ URL::asset('assets/frontend/js/modernizr-2.8.3.min.js') }}" type="text/javascript"></script>
		<script src="{{ URL::asset('assets/frontend/js/jquery.stellar.min.js') }}" type="text/javascript"></script>
		<script src="{{ URL::asset('assets/frontend/owlcarousel/js/owl.carousel.min.js') }}" type="text/javascript"></script>
		<script src="{{ URL::asset('assets/frontend/js/jquery.resize.ex.js') }}" type="text/javascript"></script>
		<script src="{{ URL::asset('assets/frontend/js/waitforimages.js') }}" type="text/javascript"></script>
		<script src="{{ URL::asset('assets/frontend/js/jquery.carousel-3d.min.js') }}" type="text/javascript"></script>
		<script src="{{ URL::asset('assets/frontend/js/form-contact.js') }}" type="text/javascript"></script>
		<script src="{{ URL::asset('assets/frontend/js/wow.min.js') }}" type="text/javascript"></script>
		<script src="{{ URL::asset('assets/frontend/js/switcher.js') }}" type="text/javascript"></script>
		<script src="{{ URL::asset('assets/frontend/js/scripts.js') }}" type="text/javascript"></script>

        <script src="{{ URL::asset('assets/backend/js/initial.js') }}"></script>
		<script>
        	$('.ava').initial(); 
        </script> 		 

    	@yield('front_js')
