@extends('frontend/index')

@section('content')
<!-- START HOME -->
		<section data-stellar-background-ratio="0.3" id="home" class="home_bg" style="background-image: url({{ URL::asset('assets/frontend/img/home-bg.gif') }}); background-size:cover; background-position: center center;">
			<div class="container">
				<div class="row">
				  <div class="col-md-8 col-sm-12 col-xs-12">
					<div class="hero-text">
						<h2 style="font-size: 45px;">Belajar Mudah? Qlevers aja</h2>
						<p>Kamu bisa bertanya, belajar, dan berbagi pengetahuan kepada teman-<br/>teman kamu, di mana saja, kapan saja.</p>
						<p><small>Semua Belajar, Semua Pintar.</small></p>
						@include('frontend.inc.botton_slide')
					</div> 
				  </div><!--- END COL -->	
				  <div class="col-md-4 col-sm-12 col-xs-12 text-center">
				  	<!--
					<div class="hero-text-img">
						<img src="{{ URL::asset('assets/frontend/img/iphone_img.jpg') }}" alt="" />
					</div>
					-->
				  </div><!--- END COL -->			  
				</div><!--- END ROW -->
			</div><!--- END CONTAINER -->
		</section>
		<!-- END  HOME -->	

		<!-- START ABOUT -->
		<section id="feature" class="about-content section-padding">
			<div class="container">
				<div class="row">
					<div class="section-title text-center wow zoomIn">
						<h2>Apa yang bisa kamu pelajari di Qlevers?</h2>
						<div class="line"></div>
						<p>Disini kamu bisa bertanya, belajar, dan berbagi ilmu apa saja. Dapatkan jawaban dengan cepat dan mudah.</p>
					</div>
					<div class="col-md-2 col-sm-3 col-xs-12">
						<div class="single_feature text-center" style="margin-top: -10px;">
							<i class="" style="background: url({{ URL::asset('assets/frontend/img/icon/matematika.png') }});background-size: 100% 100%;background-repeat: no-repeat;color: #fff;"></i>
							<h3>Matematika</h3>
						</div>
					</div><!-- END COL-->
					<div class="col-md-2 col-sm-3 col-xs-12">
						<div class="single_feature text-center" style="margin-top: -10px;">
							<i class="" style="background: url({{ URL::asset('assets/frontend/img/icon/Fisika.png') }});background-size: 100% 100%;background-repeat: no-repeat;color: #fff;"></i>
							<h3>Fisika</h3>
						</div>
					</div><!-- END COL-->
					<div class="col-md-2 col-sm-4 col-xs-12">
						<div class="single_feature text-center" style="margin-top: -10px;">
							<i class="" style="background: url({{ URL::asset('assets/frontend/img/icon/Ekonomi.png') }});background-size: 100% 100%;background-repeat: no-repeat;color: #fff;"></i>
							<h3>Ekonomi</h3>
						</div>
					</div><!-- END COL-->
					<div class="col-md-2 col-sm-4 col-xs-12">
						<div class="single_feature text-center" style="margin-top: -10px;">
							<i class="" style="background: url({{ URL::asset('assets/frontend/img/icon/Kimia.png') }});background-size: 100% 100%;background-repeat: no-repeat;color: #fff;"></i>
							<h3>Kimia</h3>
						</div>
					</div><!-- END COL-->
					<div class="col-md-2 col-sm-4 col-xs-12">
						<div class="single_feature text-center" style="margin-top: -10px;">
							<i class="" style="background: url({{ URL::asset('assets/frontend/img/icon/Inggris.png') }});background-size: 100% 100%;background-repeat: no-repeat;color: #fff;"></i>
							<h3>B.Inggris</h3>
						</div>
					</div><!-- END COL-->
					<div class="col-md-2 col-sm-4 col-xs-12">
						<div class="single_feature text-center" style="margin-top: -10px;">
							<i class="" style="background: url({{ URL::asset('assets/frontend/img/icon/Biologi.png') }});background-size: 100% 100%;background-repeat: no-repeat;color: #fff;"></i>
							<h3>Biologi</h3>
						</div>
					</div><!-- END COL-->
					<div class="col-md-12 col-sm-12 col-xs-12">
						<div class="single_feature text-center">
						<a class="single_feature_btn_light" href="javascript::" data-toggle="modal" data-target="#mylogin">Tanya Sekarang</a>
						</div>
					</div><!-- END COL-->
				</div><!-- END ROW-->
			</div><!-- END CONTAINER-->
		</section>
		<!-- END ABOUT -->
		
		<!-- START FEATURED ONE -->
		<section class="feature-one section-padding">
			<div class="container">
				<div class="row">

					<div class="col-md-5 col-sm-5 col-xs-12">
						<div class="single_feature_one">
							<h3>Benefit Untuk <strong>Guru</strong></h3>
							<p>
								<i class="fa fa-check"></i> Media berbagi ilmu kepada siswa di seluruh Indonesia
								<br/>
								<i class="fa fa-check"></i> Media tanya jawab dan interaksi dengan guru dari seluruh Indonesia
								<br/>
								<i class="fa fa-check"></i> Memperoleh rating dan rekomendasi dari qlevers
							</p>
						</div>
					</div>
					<div class="col-md-7 col-sm-7 col-xs-12">
						<div class="single_feature_img">
							<img class="img-responsive wow bounceIn" data-wow-delay=".6s" src="{{ URL::asset('assets/frontend/img/teacher.png') }}" alt="" width="70%">
						</div>
					</div>
					
				</div>
			</div>
		</section>

		<section class="feature-one section-padding">
			<div class="container">
				<div class="row">
                    @foreach(Sayembara::where('active','=','1')->with('mapel')->take(1)->get() as $soal)
					<div class="col-md-6 col-sm-6 col-xs-12">
						<div class="single_feature_img">
                              	<iframe class="wow bounceIn" data-wow-delay=".6s" width="100%" height="315" src="{{$soal->files}}" frameborder="0" allowfullscreen></iframe>
						</div>
					</div><!-- END COL-->
					<div class="col-md-6 col-sm-6 col-xs-12">
						<div class="single_feature_one" style="margin-top: -180px;">
							<h3>Quiz Sayembara <strong>Qlevers</strong></h3>
							{{$soal->body}}.
							<a class="single_feature_btn_light" href="{{url('/sayembara')}}">Jawab Pertanyaan Sekarang</a>
						</div>
					</div><!-- END COL-->
                    @endforeach
				</div><!-- END ROW-->
			</div><!-- END CONTAINER-->
		</section>
		<!-- END FEATURED ONE -->
				
		<!-- START HOW IT WORKS -->
		<section class="about_video" style="background-image: url({{ URL::asset('assets/frontend/img/bg/video-bg.jpg') }}); background-size:cover; background-position: center center;background-attachment:fixed;">
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12 text-center">
						<div class="video-container">                  						
							<a data-toggle="modal" data-target="#video-modal" data-backdrop="true">
							<span class="play-video"><span class="fa fa-play"></span></span></a>
							<h3>Watch video</h3>
						</div>
						<!-- VIDEO POPUP -->
						<div class="modal fade video-modal" id="video-modal" role="dialog">
							<div class="modal-content">
								<iframe width="712" height="480" src="https://www.youtube.com/embed/IMVOWCPKgME"></iframe>
							</div>
						</div>
						<!-- END VIDEO POPUP -->	
					</div><!--- END COL -->					
				</div><!--- END ROW -->
			</div><!--- END CONTAINER -->	
		</section>
		<!-- END HOW IT WORKS -->

		<!-- START TESTIMONIAL -->
        <section class="more_features section-padding">
	        <div class="container">
	            <div class="row">
	                <div class="col-sm-10 col-sm-offset-1 col-xs-12">
	                	<div id="team__carousel" class="carousel slide" data-ride="carousel" data-interval="9999999">
							<!-- Indicators -->
							<ol class="carousel-indicators">
							  <li data-target="#team__carousel" data-slide-to="0" class="active"></li>
							  <li data-target="#team__carousel" data-slide-to="1"></li>
							  <li data-target="#team__carousel" data-slide-to="2"></li>
							  <li data-target="#team__carousel" data-slide-to="3"></li>
							</ol>
							<div class="carousel-inner text-center">

                            @foreach(AskActivy::with('ask')->where('active','=','1')->orderBy('id', 'DESC')->take(5)->get() as $index => $av)
								<div class="item @if($index == 0) {{ 'active' }} @endif">
									<div class="testimonial-text">
										<i class="fa fa-quote-left"></i>
										<p>"{{nl2br($av->ask->body)}}"</p>
										@if($av->ask->user->avatar == '')
                                            <img class="img-responsive ava" data-name="{{$av->ask->user->first_name}}" alt=""/>
                                        @else
                                            {{ HTML::image($av->ask->user->avatar,'',array('class'=>'img-responsive','alt'=>'$av->ask->user->first_name')) }}
                                        @endif
										<h4>{{$av->ask->user->first_name}}</h4>
										<h5>{{$av->ask->mapel->title}}</h5>
									</div>
								</div>
							@endforeach

							</div>
						</div>
					</div><!--- END COL -->				
				</div><!--- END ROW -->
			</div><!--- END CONTAINER -->	
        </section>
		<!-- END TESTIMONIAL -->

@stop
