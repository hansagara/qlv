@extends('frontend/index')

@section('content')
<style type="text/css">
	.main-login{
		float: right;
	 	background-color: #fff;
	    /* shadows and rounded borders */
	    -moz-border-radius: 2px;
	    -webkit-border-radius: 2px;
	    border-radius: 2px;
	    -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
	    -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
	    box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);

	}

	.main-center{
	 	margin-top: 30px;
	 	margin: 0 auto;
	 	/*max-width: 330px;*/
	 	max-width: 100%;
	    padding: 20px 40px;

	}

	.login-button{
		margin-top: 5px;
	}

	.login-register{
		font-size: 11px;
		text-align: center;
	}
</style>
		<section data-stellar-background-ratio="0.3" id="home" class="home_bg" style="background-image: url({{ URL::asset('assets/frontend/img/ten-bg.jpg') }}); background-size:cover; background-position: center center;">
			<div class="container">
				<div class="row">
				  <div class="col-md-6 col-sm-6 col-xs-12 hidden-xs">
					<div class="hero-text text-left">
						<h2 style="color:#fff;">Ayo gabung bersama Ribuan Pelajar Lainnya</h2>
					</div> 
				  </div><!--- END COL -->
				  <div class="col-md-6 col-sm-6 col-xs-12">
					<div class="hero-text-img">
					  	<div class="main-login main-center">
                        	{{ Form::open(['route' => 'registration.store']) }}
								<div class="row">
									<div class="col-xs-12 col-sm-12 col-md-6">
										<div class="form-group">
											<label for="name" class="cols-sm-2 control-label">Nama Depan *</label>
											<div class="cols-sm-10">
												<div class="input-group">
													<span class="input-group-addon"><i class="fa fa-edit fa" aria-hidden="true"></i></span>
                                    				<input class=" form-control" id="cname" name="first_name" minlength="2" type="text" required />
												</div>
											</div>
										</div>
									</div>
									<div class="col-xs-12 col-sm-12 col-md-6">
										<div class="form-group">
											<label for="email" class="cols-sm-2 control-label">Nama Belakang *</label>
											<div class="cols-sm-10">
												<div class="input-group">
													<span class="input-group-addon"><i class="fa fa-edit fa" aria-hidden="true"></i></span>
                                    				<input class="form-control" id="cname" name="last_name" minlength="2" type="text" required />
												</div>
											</div>
										</div>
									</div>

									<div class="col-xs-12 col-sm-12 col-md-6">
										<div class="form-group">
											<label for="name" class="cols-sm-2 control-label">Jenjang *</label>
											<div class="cols-sm-10">
												<div class="input-group">
													<span class="input-group-addon"><i class="fa fa-edit fa" aria-hidden="true"></i></span>
													<select class=" form-control" name="id_jenjang" id="jenjang" required>
				                                        @foreach(Jenjang::get() as $jn)
				                                        <option value="{{$jn->id}}">{{$jn->title}}</option>
				                                        @endforeach
				                                    </select>
												</div>
											</div>
										</div>
									</div>
									<div class="col-xs-12 col-sm-12 col-md-6">
										<div class="form-group">
											<label for="email" class="cols-sm-2 control-label">Kelas *</label>
											<div class="cols-sm-10">
												<div class="input-group">
													<span class="input-group-addon"><i class="fa fa-edit fa" aria-hidden="true"></i></span>
													<select class=" form-control" id="kelas" name="id_kelas" required>
				                                        <option>Pilih Kelas</option>
				                                    </select>
												</div>
											</div>
										</div>
									</div>

									<div class="col-xs-12 col-sm-12 col-md-6">
										<div class="form-group">
											<label for="email" class="cols-sm-2 control-label">No Telp (Optional)</label>
											<div class="cols-sm-10">
												<div class="input-group">
													<span class="input-group-addon"><i class="fa fa-edit fa" aria-hidden="true"></i></span>
													<input class="form-control " type="text" name="no_contact" id="password1" required />
												</div>
											</div>
										</div>
									</div>

									<div class="col-xs-12 col-sm-12 col-md-6">
										<div class="form-group">
											<label for="name" class="cols-sm-2 control-label">E-Mail *</label>
											<div class="cols-sm-10">
												<div class="input-group">
													<span class="input-group-addon"><i class="fa fa-edit fa" aria-hidden="true"></i></span>
													<input class="form-control " id="cemail" type="email" name="email" required />
                                    				<small>{{ errors_for('email', $errors) }}</small>
												</div>
											</div>
										</div>
									</div>	

									<div class="col-xs-12 col-sm-12 col-md-6">
										<div class="form-group">
											<label for="email" class="cols-sm-2 control-label">Password *</label>
											<div class="cols-sm-10">
												<div class="input-group">
													<span class="input-group-addon"><i class="fa fa-edit fa" aria-hidden="true"></i></span>
													<input class="form-control " type="password" name="password" id="password1" required />
												</div>
											</div>
										</div>
									</div>

									<div class="col-xs-12 col-sm-12 col-md-6">
										<div class="form-group">
											<label for="email" class="cols-sm-2 control-label">Confirm Password *</label>
											<div class="cols-sm-10">
												<div class="input-group">
													<span class="input-group-addon"><i class="fa fa-edit fa" aria-hidden="true"></i></span>
													<input class="form-control" type="password" name="password_confirmation" id="password2" required />
												</div>
											</div>
										</div>
									</div>

									<div class="col-xs-12 col-sm-12 col-md-12">
										<div class="form-group ">
			                                <small>Dengan menekan tombol <b>Register</b> anda setuju dengan <a href="{{url('/pages/5/2016-09-11/syarat_dan_ketentuan')}}" style="color:#3cbea7;" target="_blank"><u>Syarat & Ketentuan</u></a> yang berlaku</small>
			                            </div>
									</div>

								</div>

								<div class="form-group ">
									<button type="submit" class="btn btn-primary btn-lg btn-block login-button">Register</button>
								</div>
								<div class="login-register">
						            Sudah punya akun? <a href="javascript::" data-toggle="modal" data-target="#mylogin">Login</a>
						         </div>
                        	{{ Form::close() }}
						</div>
					</div>
				  </div>
				</div>
			</div><!--- END CONTAINER -->
		</section>
		<!-- END  HOME -->	

@stop

@section('front_js')
<script type="text/javascript">
    $('#jenjang').change(function(){
        $.getJSON("{{ url('/register/kelas')}}", 
        { option: $(this).val() }, 
        function(data) {
            var model = $('#kelas');
            model.empty();
            $.each(data, function(index, element) {
                model.append("<option value='"+element.id+"'>" + element.title + "</option>");
            });
        });
    });
</script>

<script type="text/javascript">

$("input[type=password]").keyup(function(){
    var ucase = new RegExp("[A-Z]+");
    var lcase = new RegExp("[a-z]+");
    var num = new RegExp("[0-9]+");
    
    if($("#password1").val().length >= 8){
        $("#8char").removeClass("fa-times");
        $("#8char").addClass("fa-check");
        $("#8char").css("color","#00A41E");
    }else{
        $("#8char").removeClass("fa-check");
        $("#8char").addClass("fa-times");
        $("#8char").css("color","#FF0004");
    }
    
    if($("#password1").val() == $("#password2").val()){
        $("#pwmatch").removeClass("fa-times");
        $("#pwmatch").addClass("fa-check");
        $("#pwmatch").css("color","#00A41E");
    }else{
        $("#pwmatch").removeClass("fa-check");
        $("#pwmatch").addClass("fa-times");
        $("#pwmatch").css("color","#FF0004");
    }
});

</script>
@endsection