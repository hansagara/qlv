@extends('frontend/index')

@section('content')
<style type="text/css">
	.main-login{
		float: right;
	 	background-color: #fff;
	    /* shadows and rounded borders */
	    -moz-border-radius: 2px;
	    -webkit-border-radius: 2px;
	    border-radius: 2px;
	    -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
	    -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
	    box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);

	}

	.main-center{
	 	margin-top: 30px;
	 	margin: 0 auto;
	 	max-width: 100%;
	    padding: 20px 40px;

	}

	.login-button{
		margin-top: 5px;
	}

	.login-register{
		font-size: 11px;
		text-align: center;
	}
</style>
		<section data-stellar-background-ratio="0.3" id="home" class="home_bg" style="background-image: url({{ URL::asset('assets/frontend/img/ten-bg.jpg') }}); background-size:cover; background-position: center center;">
			<div class="container">
				<div class="row">
				  <div class="col-md-6 col-sm-6 col-xs-12">
					<div class="hero-text text-left">
						<h2>Ayo gabung bersama Ribuan Pelajar Lainnya</h2>
					</div> 
				  </div><!--- END COL -->
				  <div class="col-md-6 col-sm-6 col-xs-12">
					<div class="hero-text-img">
					  	<div class="main-login main-center">

					  		@if (Session::has('flash_message'))
					  			<div class="alert alert-success">
	                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
	                                <div class="media-left">
	                                    <i class="fa fa-check fa-lg"></i>
	                                </div>
	                                <div class="media-body">
	                                    <h4 class="alert-title">{{ Session::get('flash_message') }}</h4>
	                                </div>
	                            </div>
							@endif

							@if (Session::has('error_message'))
								<div class="alert alert-danger">
	                                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">×</button>
	                                <div class="media-left">
	                                    <i class="fa fa-remove fa-lg"></i>
	                                </div>
	                                <div class="media-body">
	                                    <h4 class="alert-title">{{ Session::get('error_message') }}</h4>
	                                </div>
	                            </div>
							@endif
					  		
				    		{{ Form::open(['action' => 'RemindersController@postReset']) }}
								<div class="form-group">
									<label for="email" class="cols-sm-2 control-label">Your Email</label>
									<div class="cols-sm-10">
										<div class="input-group">
											<span class="input-group-addon"><i class="fa fa-envelope fa" aria-hidden="true"></i></span>
											<input type="text" class="form-control" name="email" id="email" required="required" placeholder="Enter your Email"/>
										</div>
									</div>
								</div>

								<div class="form-group">
									<label for="email" class="cols-sm-2 control-label">New Password *</label>
									<div class="cols-sm-10">
										<div class="input-group">
											<span class="input-group-addon"><i class="fa fa-edit fa" aria-hidden="true"></i></span>
											<input class="form-control " type="password" name="password" id="password1" required />
											{{ errors_for('password', $errors) }}
										</div>
									</div>
								</div>

								<div class="form-group">
									<label for="email" class="cols-sm-2 control-label">Confirm New Password *</label>
									<div class="cols-sm-10">
										<div class="input-group">
											<span class="input-group-addon"><i class="fa fa-edit fa" aria-hidden="true"></i></span>
											<input class="form-control" type="password" name="password_confirmation" id="password2" required />
											{{ errors_for('password', $errors) }}
										</div>
									</div>
								</div>
								{{ Form::hidden('token', $token )}}
								{{ errors_for('email', $errors) }}
								<div class="form-group ">
									<button type="submit" class="btn btn-primary btn-lg btn-block login-button">Reset Password</button>
								</div>
								<div class="login-register">
						            Belum punya akun? <a href="{{url('pages/register')}}">Register</a>
						         </div>
                        	{{ Form::close() }}
						</div>
					</div>
				  </div>
				</div>
			</div><!--- END CONTAINER -->
		</section>
		<!-- END  HOME -->	

@stop