@extends('frontend/index')

@section('content')
<style type="text/css">
	.main-login{
		float: right;
		width: 100%;
	 	background-color: #fff;
	    /* shadows and rounded borders */
	    -moz-border-radius: 2px;
	    -webkit-border-radius: 2px;
	    border-radius: 2px;
	    -moz-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
	    -webkit-box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
	    box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);

	}

	.main-center{
	 	margin-top: 30px;
	 	margin: 0 auto;
	 	max-width: 330px;
	    padding: 20px 40px;

	}

	.login-button{
		margin-top: 5px;
	}

	.login-register{
		font-size: 11px;
		text-align: center;
	}
</style>
		<section data-stellar-background-ratio="0.3" id="home" class="home_bg" style="background-image: url({{ URL::asset('assets/frontend/img/ten-bg.jpg') }}); background-size:cover; background-position: center center;">
			<div class="container">
				<div class="row">
				  <div class="col-md-6 col-sm-6 col-xs-12">
					<div class="hero-text text-left">
						<h2>Ayo gabung bersama Ribuan Pelajar Lainnya</h2>
					</div> 
				  </div><!--- END COL -->
				  <div class="col-md-6 col-sm-6 col-xs-12">
					<div class="hero-text-img">
					  	<div class="main-login main-center">
                        	{{ Form::open(['route' => 'sessions.store','class'=>'form-horizontal']) }}
							
								<div class="form-group">
									<label for="email" class="cols-sm-2 control-label">Your Email</label>
									<div class="cols-sm-10">
										<div class="input-group">
											<span class="input-group-addon"><i class="fa fa-envelope fa" aria-hidden="true"></i></span>
											<input type="text" class="form-control" name="email" id="email"  placeholder="Enter your Email"/>
										</div>
									</div>
								</div>

								<div class="form-group">
									<label for="password" class="cols-sm-2 control-label">Password</label>
									<div class="cols-sm-10">
										<div class="input-group">
											<span class="input-group-addon"><i class="fa fa-lock fa-lg" aria-hidden="true"></i></span>
											<input type="password" class="form-control" name="password" id="password"  placeholder="Enter your Password"/>
										</div>
									</div>
								</div>

								<div class="form-group ">
									<button type="submit" class="btn btn-primary btn-lg btn-block login-button">Login</button>
								</div>
								<div class="login-register">
						            Belum punya akun? <a href="{{url('pages/register')}}">Register</a>
						         </div>
                        	{{ Form::close() }}
						</div>
					</div>
				  </div>
				</div>
			</div><!--- END CONTAINER -->
		</section>
		<!-- END  HOME -->	

@stop