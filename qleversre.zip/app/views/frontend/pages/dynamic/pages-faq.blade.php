@extends('frontend/index')

@section('content')
<style type="text/css">
	.panel-title > a:before {
    float: right !important;
    font-family: FontAwesome;
    content:"\f055";
    padding-right: 5px;
}
.panel-title > a.collapsed:before {
    float: right !important;
    content:"\f056";
}
.panel-title > a:hover, 
.panel-title > a:active, 
.panel-title > a:focus  {
    text-decoration:none;
}
</style>
	<section data-stellar-background-ratio="0.3" id="home" class="home_bg" style="background-image: url({{ URL::asset('assets/frontend/img/col-bg.jpg') }}); background-size:cover; background-position: center center;">
			<div class="container">
				<div class="row">
				  <div class="col-md-12 col-sm-12 col-xs-12">
					<div class="hero-text text-center">
						<h2>Frequently Asked Questions</h2>
						@include('frontend.inc.botton_slide')
					</div> 
				  </div><!--- END COL -->
				</div>

				@include('frontend.inc.menu_slide')

			</div><!--- END CONTAINER -->
		</section>
		<!-- END  HOME -->	

				<!-- START FEATURED ONE -->
		<section class="feature-one section-padding">
			<div class="container">
				<div class="row">
					<div class="section-title text-center wow zoomIn">
						<h2>FAQ</h2>
						<div class="line"></div>
					</div>
					<div class="col-md-12 col-sm-12 col-xs-12">

						<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
							{{-- */$i=1;/* --}}
                			@foreach($content as $index => $kon)
						    <div class="panel panel-default">
						        <div class="panel-heading" role="tab" id="{{$kon->id}}">
						            <h4 class="panel-title">
								        <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne{{$kon->id}}" aria-expanded="true" aria-controls="collapseOne{{$kon->id}}">
								           {{$kon->title}} #{{ $i++ }}
								        </a>
								    </h4>

						        </div>
						        <div id="collapseOne{{$kon->id}}" class="panel-collapse collapse @if($index == 0) {{ 'in' }} @endif" role="tabpanel" aria-labelledby="{{$kon->id}}">
						            <div class="panel-body">{{$kon->body}}</div>
						        </div>
						    </div>
                        	@endforeach
						</div>

					</div><!-- END COL-->
				</div><!-- END ROW-->
			</div><!-- END CONTAINER-->
		</section>
		<!-- END FEATURED ONE -->

				<!-- START HOW IT WORKS -->
		<section class="about_video" style="background-image: url({{ URL::asset('assets/frontend/img/bg/video-bg.jpg') }}); background-size:cover; background-position: center center;background-attachment:fixed;">
			<div class="container">
				<div class="row">
					<div class="col-md-12 col-sm-12 col-xs-12 text-center">
						<div class="video-container">                  						
							<a data-toggle="modal" data-target="#video-modal" data-backdrop="true">
							<span class="play-video"><span class="fa fa-play"></span></span></a>
							<h3>Watch video</h3>
						</div>
						<!-- VIDEO POPUP -->
						<div class="modal fade video-modal" id="video-modal" role="dialog">
							<div class="modal-content">
								<iframe width="712" height="400" src="../../../www.youtube.com/embed/EWan2YcodSM.htm"></iframe>
							</div>
						</div>
						<!-- END VIDEO POPUP -->	
					</div><!--- END COL -->					
				</div><!--- END ROW -->
			</div><!--- END CONTAINER -->	
		</section>
		<!-- END HOW IT WORKS -->
@stop