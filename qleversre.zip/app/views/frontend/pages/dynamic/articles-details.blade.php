@extends('frontend/index')

@section('content')
	<section data-stellar-background-ratio="0.3" id="home" class="home_bg" style="background-image: url({{ URL::asset('assets/frontend/img/col-bg.jpg') }}); background-size:cover; background-position: center center;">
			<div class="container">
				<div class="row">
				  <div class="col-md-12 col-sm-12 col-xs-12">
					<div class="hero-text text-center">
						<h2>Cara Kerja Qlevers</h2>
						@include('frontend.inc.botton_slide')
					</div> 
				  </div><!--- END COL -->
				</div>

				@include('frontend.inc.menu_slide')

			</div><!--- END CONTAINER -->
		</section>
		<!-- END  HOME -->	
		
		<!-- START FEATURED ONE -->
		<section class="feature-one section-padding">
			<div class="container">
				<div class="row">
					<div class="col-md-5 col-sm-5 col-xs-12">
						<div class="single_feature_img">
							<img class="img-responsive wow bounceIn" data-wow-delay=".6s" src="{{ URL::asset('assets/frontend/img/smart.png') }}" alt="">
						</div>
					</div><!-- END COL-->
					<div class="col-md-7 col-sm-7 col-xs-12">
						<div class="single_feature_one" style="margin-top: -50px;">
							<h3>How It <strong>Works </strong></h3>
							<p>Ketika siswa mempunyai kesulitan belajar, siswa dapat dengan mudah mengunggahnya di aplikasi Qlever, kemudian siswa akan mendapat jawaban yang terverifikasi dari pengajar-pengajar yang berdedikasi membantu, tidak  hanya itu, siswa kemudian bisa melakukan share kegiatan belajar mereka di platform social media lainnya. Kami yakin semua siswa punya kelebihan,mereka bisa membantu dan berbagai dengan siswa lainnya.</p> 
						</div>
					</div><!-- END COL-->
				</div><!-- END ROW-->
			</div><!-- END CONTAINER-->
		</section>
		<!-- END FEATURED ONE -->
		
		<section class="feature-two section-padding">
			<div class="container">
				<div class="row">
					<div class="col-md-7 col-sm-7 col-xs-12">
						<div class="single_feature_two" style="margin-top: -150px;">
							<h3>Mengapa <strong>Qlever ?</strong></h3>
							<p>Dengan menggunakan QLever, siswa dapat memperoleh manfaat berupa:</p>  

							<strong>Belajar dimana &amp; kapan saja</strong>. 
							<br/>Siswa dan guru dapat memilih untuk berinteraksi pada waktu dan tempat yang nyaman.

							<p><strong>Keselamatan dan keamanan</strong>. 
							<br/>Proses pembelajaran dapat berlangsung di rumah dan di bawah pengawasan orangtua untuk memastikan keselamatan siswa.</p>

							<p><strong>Kualitas guru</strong>. 
							<br>Para pengajar di Qlever dipilih dengan hati-hati dan secara rutin dipantau. Sebagian besar pengajar berasal dari universitas ternama dan memiliki pengalaman akademik dalam mengajar.</p>  

							<p><strong>Personalized </strong><strong>learning</strong>. 
							<br>DI Qlever Fokus utama kami adalah pada kegiatan mengajar 1-on-1. Siswa akan mendapat perhatian secara individu, tidak seperti ruang kelas yang ramai di mana banyak siswa merasa enggan mengajukan pertanyaan. Hal ini menghasilkan pemahaman yang lebih baik terhadap bahan pelajaran.</p>  

							<p><strong>Feedback untuk Siswa dan Orangtua. </strong>
							<br/>Setiap sesi pembelajaran dan perkembangan belajar di Qlever akan tercatat secara online untuk kemudian dapat dipelajari kembali.</p>
						</div>
					</div><!-- END COL-->
					<div class="col-md-5 col-sm-5 col-xs-12">
						<div class="single_feature_two_img">
							<img class="img-responsive wow bounceIn" data-wow-delay=".6s" src="{{ URL::asset('assets/frontend/img/edu.png') }}" alt="">
						</div>
					</div><!-- END COL-->
				</div><!-- END ROW-->
			</div><!-- END CONTAINER-->
		</section>
		
@stop