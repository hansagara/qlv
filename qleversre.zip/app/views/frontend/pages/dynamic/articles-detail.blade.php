@extends('frontend/index')

@section('content')
<!-- START HOME -->
		<section data-stellar-background-ratio="0.3" id="home" class="home_bg" style="background-image: url({{ URL::asset('assets/frontend/img/ten-bg.jpg') }}); background-size:cover; background-position: center center;">
			<div class="container">
				<div class="row">
				  <div class="col-md-12 col-sm-12 col-xs-12">
					<div class="hero-text text-center">
						<h2>Membantu Ribuan Pelajar di Indonesia</h2>
						@include('frontend.inc.botton_slide')
					</div> 
				  </div><!--- END COL -->
				</div>

				@include('frontend.inc.menu_slide')

			</div><!--- END CONTAINER -->
		</section>
		<!-- END  HOME -->	
		
		<!-- START FEATURED ONE -->
		<section class="feature-one section-padding" style="background-color: #FEC20F; color: #000; background-size:cover; background-position: center center;background-attachment:fixed;">
			<div class="container">
				<div class="row">
					<div class="col-md-5 col-sm-5 col-xs-12">
						<div class="single_feature_img">
							<img class="img-responsive wow bounceIn" data-wow-delay=".6s" src="{{ URL::asset('assets/frontend/img/smart.png') }}" alt="">
						</div>
					</div><!-- END COL-->
					<div class="col-md-7 col-sm-7 col-xs-12">
						<div class="single_feature_one" style="margin-top: -80px;">
							<h3 style="color: #000;">Apa Itu <strong>Qlevers.com? </strong></h3>
							<p>Qlevers.com adalah media sosial yang mempermudah murid, guru, atau siapa saja untuk berinteraksi, berbagi, dan saling belajar ilmu pengetahuan dimanapun, dan kapanpun.</p>
							<p>
							Disini kamu bisa bertanya dan berbagi pengetahuan yang kamu punya untuk disebarkan kepada semua teman-teman kamu.
							</p>
							<p/>Kamu akan dibantu oleh teman-teman kamu di mana saja untuk dapat mengeksplorasi pengetahuan dan menemukan jawaban atas pertanyaan kamu di pelajaran.</p> 
						</div>
					</div><!-- END COL-->
				</div><!-- END ROW-->
			</div><!-- END CONTAINER-->
		</section>
		<!-- END FEATURED ONE -->
		
		<section class="feature-two section-padding">
			<div class="container">
				<div class="row">
					<div class="col-md-7 col-sm-7 col-xs-12">
						<div class="single_feature_two">
							<h3>Latar Belakang</h3>
							<p>
								Ilmu pengetahuan dan pelajaran tidak hanya merupakan sebuah kewajiban, tapi lebih dari itu, adalah sebuah kebutuhan. Namun, akses terhadap pendidikan masih menjadi tantangan yang besar di Indonesia, dan tidak semua orang dapat memiliki kesempatan belajar dan memperoleh ilmu dengan kualitas yang sama.
							</p>
							<p>
								Misi kami adalah untuk menjadi jaringan pembelajaran sosial terbesar bagi seluruh siswa Indonesia untuk dapat berbagi, saling membantu, dan belajar bersama. Qlevers adalah media dimana kamu dapat berinteraksi dengan teman-teman kamu dimana pun dan kapan pun dengan cara yang mudah dan menyenangkan.
							</p>
						</div>
					</div><!-- END COL-->
					<div class="col-md-5 col-sm-5 col-xs-12">
						<div class="single_feature_two_img">
							<img class="img-responsive wow bounceIn" data-wow-delay=".6s" src="{{ URL::asset('assets/frontend/img/edu.png') }}" alt="">
						</div>
					</div><!-- END COL-->
				</div><!-- END ROW-->
			</div><!-- END CONTAINER-->
		</section>
		
		<!-- START HOW IT WORKS -->
		<section class="about_video" style="background-image: url({{ URL::asset('assets/frontend/img/bg/video-bg.jpg') }}); color: #fff; background-size:cover; background-position: center center;background-attachment:fixed;">
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-sm-8 col-xs-12">
						<h3 style="color: #fff;">Impian <strong>Kami</strong></h3>
						<p>Impian kami adalah meniciptakan dunia pendidikan dengan sistem yang bisa memfasilitasi pembelajaran kapanpun, dan dimanapun. Membuat pendidikan berkualitas bisa diakses oleh semua orang. Bisa menyebarkan pengetahuan tanpa batasan apapun. Dan, menjaring dan menciptakan pengajar-pengajar berkualitas</p>
						<!-- END VIDEO POPUP -->	
					</div><!--- END COL -->					
					<div class="col-md-4 col-sm-4 col-xs-12"></div>
				</div><!--- END ROW -->
			</div><!--- END CONTAINER -->	
		</section>
		<!-- END HOW IT WORKS -->
@stop