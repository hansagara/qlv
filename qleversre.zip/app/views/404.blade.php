@extends('frontend/pages_layout')

@section('content')
	<section class="page-content">
        <div class="container">
            <div class="row">
                <div class="col-md-4 col-md-offset-4 text-center">
                    <div class="not-found-content">
                        <h1>404</h1>
                        <h3>UPS! Maaf</h3>
                        <p>Kami tidak menemukan halaman yang anda cari.</p>
                        @if($error)
                            <p>{{$error}}</p>
                        @else
                        @endif
                    </div>                                     
                    <div class="back-to-home">
                        <a href="javascript:history.back()">Go to Homepage</a>
                    </div>

                    <link rel="canonical" href="{{url('/')}}"/>
                    <noscript>
                        <meta http-equiv="refresh" content="5;URL={{url('/')}}">
                    </noscript>
                    <!--[if lt IE 9]><script type="text/javascript">var IE_fix=true;</script><![endif]-->
                    <script type="text/javascript">
                        var url = "{{url('/')}}";
                        var delay = "1000";
                        window.onload = function ()
                        {
                            setTimeout(GoToURL, delay);
                        }
                        function GoToURL()
                        {
                            if(typeof IE_fix != "undefined") // IE8 and lower fix to pass the http referer
                            {
                                var referLink = document.createElement("a");
                                referLink.href = url;
                                document.body.appendChild(referLink);
                                referLink.click();
                            }
                            else { window.location.replace(url); } // All other browsers
                        }
                    </script> 

                </div>                
            </div>
        </div>
    </section>
@stop