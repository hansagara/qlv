<?php

return array(

	/*
	|--------------------------------------------------------------------------
	| oAuth Config
	|--------------------------------------------------------------------------
	*/

	/**
	 * Consumers
	 */
	'consumers' => array(

		/**
		 * Facebook
		 */
        'Facebook' => array(
            'client_id'     => '1348402645194182',
            'client_secret' => 'dcee73b39f923a21d8492e9b7f09bc70',
            'scope'         => array('email','public_profile','user_friends'),
        ),

        'Google' => array(
		    'client_id'     => '73675009282-io0lnuef2nibd1vbkmh3rfvkbe972iuc.apps.googleusercontent.com',
		    'client_secret' => 'utB798U45lSEoNT7jeQ3fpRK',
		    'scope'         => array('userinfo_email', 'userinfo_profile'),
		),  

	)

);