<?php

class oAuthController extends \BaseController {

    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function Google()
    {
        // get data from input
        $code = Input::get( 'code' );

        // get google service
        $googleService = OAuth::consumer( 'Google' );

        // check if code is valid

        // if code is provided get user data and sign in
        if ( !empty( $code ) ) {

            // This was a callback request from google, get the token
            $token = $googleService->requestAccessToken( $code );

            // Send a request with it
            $result = json_decode( $googleService->request( 'https://www.googleapis.com/oauth2/v1/userinfo' ), true );

            if(!empty($token)){

                try{
                    // Find the user using the user id
                    $user = Sentry::findUserByLogin($result['email']);

                    // Log the user in
                    Sentry::login($user, false);

                    return Redirect::to('/');
                }
                catch (\Cartalyst\Sentry\Users\UserNotFoundException $e)
                {
                    // Register the user
                    $user = Sentry::register(array(
                        'activated' =>  1,
                        'verification' =>  0,
                        'register_with' =>  'google',
                        'email'      => $result['email'],
                        'password'   => Hash::make(uniqid(time())),
                        'first_name' => $result['name'],
                        'avatar'   => $result['picture']
                    ));

                    $usergroup = Sentry::findGroupByName('Users');
                    $user->addGroup($usergroup);

                    Sentry::login($user, false);

                    return Redirect::to('/');
                }

            }

        }
        // if not ask for permission first
        else {
            // get googleService authorization
            $url = $googleService->getAuthorizationUri();

            // return to facebook login url
            return Redirect::to( (string)$url );
        }
    }


    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function Facebook()
    {

            // get data from input
        $code = Input::get( 'code' );

        // get fb service
        $fb = OAuth::consumer( 'Facebook' );

        // check if code is valid

        // if code is provided get user data and sign in
        if ( !empty( $code ) ) {

            // This was a callback request from facebook, get the token
            $token = $fb->requestAccessToken( $code );

            // Send a request with it
            $result = json_decode( $fb->request( '/me?fields=id,name,first_name,last_name,email' ), true );

            if(!empty($token)){

                try{
                    // Find the user using the user id
                    $user = Sentry::findUserByLogin($result['email']);

                    // Log the user in
                    Sentry::login($user, false);

                    return Redirect::to('/');
                }
                catch (\Cartalyst\Sentry\Users\UserNotFoundException $e)
                {
                    // Register the user
                    $user = Sentry::register(array(
                        'activated' =>  1,
                        'verification' =>  0,
                        'register_with' =>  'facebook',
                        'email'      => $result['email'],
                        'password'   => Hash::make(uniqid(time())),
                        'first_name' => $result['first_name'],
                        'last_name' => $result['last_name']
                    ));

                    $usergroup = Sentry::findGroupByName('Users');
                    $user->addGroup($usergroup);

                    Sentry::login($user, false);

                    return Redirect::to('/');
                }

            }

        }
        // if not ask for permission first
        else {
            // get fb authorization
            $url = $fb->getAuthorizationUri();

            // return to facebook login url
             return Redirect::to( (string)$url );
        }

    }


}
