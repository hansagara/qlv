<?php

use basicAuth\Repo\UserRepositoryInterface;
use basicAuth\formValidation\UsersEditForm;

class UsersController extends \BaseController {

	/**
	 * @var $user
	 */
	protected $user;

	/**
	* @var usersEditForm
	*/
	protected $usersEditForm;

	/**
	* @param UsersEditForm $usersEditForm
	*/
	function __construct(UserRepositoryInterface $user, UsersEditForm $usersEditForm)
	{
		$this->user = $user;
		$this->usersEditForm = $usersEditForm;

		$this->beforeFilter('currentUser', ['only' => ['show', 'edit', 'update']]);
	}


	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		// $user = User::findOrFail($id);
		$user = $this->user->find($id);

		return View::make('backend.student.profile.view')->withUser($user);

	}

	public function getStudentProfiles($id)
	{
		$user = $this->user->find($id);
		return View::make('backend.student.profile.user')->withUser($user);
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		// $user = User::findOrFail($id);
		$user = $this->user->find($id);

		return View::make('backend.student.profile.edit')->withUser($user);
	}

	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{

		// $user = User::findOrFail($id);
		$user = $this->user->find($id);

		if (! Input::has("password"))
		{
			$input = Input::only('email', 'first_name', 'last_name','no_contact','id_jenjang','id_kelas');

			$this->usersEditForm->excludeUserId($user->id)->validate($input);

			$user->fill($input)->save();

			return Redirect::back()->withFlashMessage('User has been updated successfully!');
		}

		else
		{
			$input = Input::only('email', 'first_name', 'last_name','no_contact','id_jenjang','id_kelas','password', 'password_confirmation');

			$this->usersEditForm->excludeUserId($user->id)->validate($input);

			$input = array_except($input, ['password_confirmation']);

			$user->fill($input)->save();

			$user->save();

			return Redirect::back()->withFlashMessage('User (and password) has been updated successfully!');
		}
	}

	
	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function getComplate()
	{
		return View::make('backend.student.complate.home');
	}

	public function postCompleteForm($id)
	{
		$rules = array(
            'id_jenjang'              => '',
            'id_jenjang' => ''
        );

		$validator = Validator::make(Input::all(), $rules);

		if ($validator->passes()){
			
			$q 					 = User::find($id);
			$q->first_name 		 = Input::get('first_name');
			$q->last_name 		 = Input::get('last_name');
			$q->id_jenjang 		 = Input::get('id_jenjang');
 			$q->id_jenjang 		 = Input::get('id_kelas');
			$q->verification	 = '1';
			$q->save();

		return Redirect::to('/');
		}
		return Redirect::back()
			->withInput();
	}

}