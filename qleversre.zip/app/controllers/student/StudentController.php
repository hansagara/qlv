<?php

class StudentController extends \BaseController {


	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function getHome()
	{
		return View::make('backend.student.dashboard.home');
	}

	public function getRank()
	{
		return View::make('backend.student.rank.index');
	}

	public function getStudentMedia()
	{
		return View::make('backend.student.profile.media');
	}

	public function getStudentAskHistory()
	{
		return View::make('backend.student.profile.history');
	}

	public function getSearch()
	{
		$keyword=  Input::get('keyword');
		return View::make('backend.student.search.index', compact('keyword'));
	}

	public function getMapelSearch($id)
	{
		$idmapel=  $id;
		return View::make('backend.student.search.mapel', compact('idmapel'));
	}

}