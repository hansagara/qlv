<?php

class AskController extends \BaseController {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		//
	}

	public function getVotes()
	{
		$validator = Validator::make(Input::all(), Votes::$rules);

		if ($validator->passes()){

			$q 					 = new Votes;
			$q->active 			 = '1';
			$q->id_user 	 	 = Input::get('user');
			$q->membantu	 	 = Input::get('votes2');
			$q->trouble 		 = Input::get('votes3');
			$q->body 			 = Input::get('body');

			$q->save();

		return Redirect::back();
		}
		return Redirect::back()
			->withInput();
	}
	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
		//
	}


	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		$validator = Validator::make(Input::all(), Ask::$rules);

		if ($validator->passes()){

			$q 					 = new Ask;
			$q->active 			 = '1';
			$q->id_pelajaran 	 = (Input::get('mapel') == "") ? 1 : Input::get('mapel');
			$q->id_user	 		 = Input::get('user');
			$q->body 			 = Input::get('pertanyaan');
			//For image
			$image 				 = Input::file('images');

			/*
			if(Input::hasFile('images'))
		    	{
					$img 			= Input::file('images');
			        // lalu proses gambar
			        $img = Image::make($image->getRealPath());
			        // melakukan resize jika width gambar lebih dari 800
			        $img->resize(Input::get('w'), Input::get('h'))->rotate(0)->crop(Input::get('w'), Input::get('h'), Input::get('y'), Input::get('x'));

			        // menentukan direktori tempat gambar akan disimpan
		    		$filename 		= 'qlever-'.time().'.'.$image->guessExtension();
			        $path_dir = public_path('upload/ask/' .$filename);
			        // upload ke direktori yang sudah ditentukan
			        $move = $img->save($path_dir);

					if($move) {
						$q->files 		= 'upload/ask/'.$filename;
					}

				}
			*/
				if(Input::hasFile('images'))
		    	{
					$img 			= Input::file('images');
			        // lalu proses gambar
			        $img = Image::make($image->getRealPath());
			        // melakukan resize jika width gambar lebih dari 800
			        $img->resize(600, null, function ($constraint) {
			            $constraint->aspectRatio();
			        });
			        // melakukan resize jika height gambar lebih dari 600
			        $img->resize(null, 400, function ($constraint) {
			            $constraint->aspectRatio();
			        });

			        // menentukan direktori tempat gambar akan disimpan
		    		$filename 		= 'qlever-'.time().'.'.$image->guessExtension();
			        $path_dir = public_path('upload/ask/' .$filename);
			        // upload ke direktori yang sudah ditentukan
			        $move = $img->save($path_dir);

					if($move) {
						$q->files 		= 'upload/ask/'.$filename;
					}

				}

			$q->save();

			if($q->save()){
				$av = new AskActivy;
				$av->id_ask = $q->id;
				$av->active = '1';
				$av->save();

				Mail::send('emails.mail_to_guru', array('body' => Input::get('pertanyaan')), function($message)
				{
			    	$message->to('guru.qlevers@gmail.com','Guru Qlevers')->subject('Ada pertanyaan baru di qlevers');
				});
			}

		return Redirect::back();
    	//return Response::json($data, 200);
		}
		return Redirect::back()
			->withInput();
	}

	public function storeComment()
	{
		$validator = Validator::make(Input::all(), Comment::$rules);

		if ($validator->passes()){

			$c 					 = new Comment;
			$c->active 			 = '1';
			$c->id_ask 	 		 = Input::get('ask');
			$c->id_user	 		 = Input::get('from');
			$c->body 			 = Input::get('body');
			//For image
			$image 				 = Input::file('images');

			if(Input::hasFile('images'))
		    	{
					$img 			= Input::file('images');
			        // lalu proses gambar
			        $img = Image::make($image->getRealPath());
			        // melakukan resize jika width gambar lebih dari 800
			        $img->resize(700, null, function ($constraint) {
			            $constraint->aspectRatio();
			        });
			        // melakukan resize jika height gambar lebih dari 600
			        $img->resize(null, 500, function ($constraint) {
			            $constraint->aspectRatio();
			        });

			        $img->insert('assets/blog/img/watermark.png');
			        // menentukan direktori tempat gambar akan disimpan
		    		$filename 		= 'qlever-'.time().'.'.$image->guessExtension();
			        $path_dir = public_path('upload/comment/' .$filename);
			        // upload ke direktori yang sudah ditentukan
			        $move = $img->save($path_dir);

					if($move) {
						$c->files 		= 'upload/comment/'.$filename;
					}

				}

			$c->save();

			if($c->save()){

				if ($c->id_user == Input::get('to')) {
					
				}
				else{
					$av = new Notification;
					$av->id_activi = $c->id;
					$av->id_from = $c->id_user;
					$av->id_to = Input::get('to');
					$av->active = '1';
					$av->type = 'comment';
					$av->save();
				}

			}

		return Redirect::back();
    	//return Response::json($data, 200);
		}
		return Redirect::back()
			->withInput();
	}

	public function getRating()
	{
		$ratingid = Input::get('id');
		$rating = Input::get('rating');

		if(!empty($rating) && !empty($ratingid)) {
			$data 			= Comment::find($ratingid);
			$data->rating 	= $rating;
			$data->save();
		}
	}

	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		$tugas = AskActivy::with('ask')->where('active','=','1')->find($id);
		return View::make('backend.student.tugas.view', compact('tugas'));
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		//
	}


	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		//
	}


	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		//
	}


}
