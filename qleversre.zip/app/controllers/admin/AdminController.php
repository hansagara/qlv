<?php

class AdminController extends \BaseController {


	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function getHome()
	{
		return View::make('backend.admin.dashboard.dashboard');
	}

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */

	public function getBlog()
	{
		return View::make('backend.admin.blog.list');
	}

	public function getAddBlog()
	{
		return View::make('backend.admin.blog.add');
	}

	public function getPostBlog()
	{
		$validator = Validator::make(Input::all(), BlogArticles::$rules);

		if ($validator->passes()){

			$q 					 = new BlogArticles;
			$q->id_categories 	 = Input::get('kategori');
			$q->active 		 	 = Input::get('active');
			$q->title	 		 = Input::get('title');
			$q->description 	 = Input::get('deskripsi');
			$q->body 			 = Input::get('body');
			$q->slug 			 = Input::get('slug');
			$q->tags 			 = Input::get('tags');
			//For image
			$image 				 = Input::file('images');

			if(Input::hasFile('images'))
		    	{
					$img 			= Input::file('images');
			        // lalu proses gambar
			        $img = Image::make($image->getRealPath());
			        // melakukan resize jika width gambar lebih dari 800
			        $img->resize(700, null, function ($constraint) {
			            $constraint->aspectRatio();
			        });
			        // melakukan resize jika height gambar lebih dari 600
			        $img->resize(null, 500, function ($constraint) {
			            $constraint->aspectRatio();
			        });
			        //menambah watermark
			        $img->insert('assets/blog/img/watermark.png');
			        // menentukan direktori tempat gambar akan disimpan
		    		$filename 		= 'qlevers-'.time().'.'.$image->guessExtension();
			        $path_dir = public_path('upload/articles/' .$filename);
			        // upload ke direktori yang sudah ditentukan
			        $move = $img->save($path_dir);

					if($move) {
						$q->files 		= 'upload/articles/'.$filename;
					}
				}

			$q->save();

		return Redirect::to('admin/list/blog');
		}
		return Redirect::back()
			->withInput();
	}

	public function getEditBlog($id)
	{
		$edit = BlogArticles::with('bcat')->find($id);
		return View::make('backend.admin.blog.edit',compact('edit'));
	}

	public function getUpdateBlog()
	{
		$validator = Validator::make(Input::all(), BlogArticles::$rules);

		if ($validator->passes()){

			$q 					 = BlogArticles::find(Input::get('iduser'));
			$q->id_categories 	 = Input::get('kategori');
			$q->active 		 	 = Input::get('active');
			$q->title	 		 = Input::get('title');
			$q->description 	 = Input::get('deskripsi');
			$q->body 			 = Input::get('body');
			$q->slug 			 = Input::get('slug');
			$q->tags 			 = Input::get('tags');
			//For image
			$image 				 = Input::file('images');

			if(Input::hasFile('images'))
		    	{
					$img 			= Input::file('images');
			        // lalu proses gambar
			        $img = Image::make($image->getRealPath());
			        // melakukan resize jika width gambar lebih dari 800
			        $img->resize(700, null, function ($constraint) {
			            $constraint->aspectRatio();
			        });
			        // melakukan resize jika height gambar lebih dari 600
			        $img->resize(null, 500, function ($constraint) {
			            $constraint->aspectRatio();
			        });
			        //menambah watermark
			        $img->insert('assets/blog/img/watermark.png');
			        // menentukan direktori tempat gambar akan disimpan
		    		$filename 		= 'qlevers-'.time().'.'.$image->guessExtension();
			        $path_dir = public_path('upload/articles/' .$filename);
			        // upload ke direktori yang sudah ditentukan
			        $move = $img->save($path_dir);

					if($move) {
						$q->files 		= 'upload/articles/'.$filename;
					}
				}

			$q->save();

		return Redirect::to('admin/list/blog');
		}
		return Redirect::back()
			->withInput();
	}

	public function getDeleteBlog($id)
	{
		$docfile = BlogArticles::find($id);
		if ($docfile) {
			$docfile->delete();
	        File::delete($docfile->files);
	        
		return Redirect::back();
		}
		return Redirect::back();
	}

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */

	public function cartTugas()
	{
		return View::make('backend.admin.report.tugas');
	}

	public function cartVotes()
	{
		return View::make('backend.admin.report.votes');
	}

}