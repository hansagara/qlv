<?php

class PagesController extends \BaseController {


	public function getHome()
	{
		return View::make('frontend.home.home');
	}

	public function getMenu($id)
	{
		$menus = Menu::find($id);
		$content = Article::where('id_menu','=',$id)->where('active','=','1')->get();
		$team = Founder::where('id_menu','=',$id)->where('active','=','1')->get();
		$table = compact('menus','content','team');
		
		if ($menus->body == 'article-detail'){
			return View::make('frontend.pages.dynamic.articles-detail',$table);
		}

		elseif ($menus->body == 'article-details'){
			return View::make('frontend.pages.dynamic.articles-details',$table);
		}

		elseif ($menus->body == 'pages-team'){
			return View::make('frontend.pages.dynamic.pages-team',$table);
		}

		elseif ($menus->body == 'pages-faq'){
			return View::make('frontend.pages.dynamic.pages-faq',$table);
		}

		else{
			return View::make('404');
		}

	}

	public function getFounder($id)
	{
		$team = Founder::where('active','=','1')->find($id);
		return View::make('frontend.pages.dynamic.view-team',compact('team'));
	}

	public function getContact()
	{
		return View::make('frontend.pages.static.contact');
	}

	public function getAsk()
	{
		return View::make('frontend.ask.home');
	}

	public function getAskView($id)
	{
		$tugas = AskActivy::with('ask')->where('active','=','1')->find($id);
		return View::make('frontend.ask.tugas.index', compact('tugas'));
	}

	public function getRss()
	{
	    $topics = Ask::with('user')->where('active','=','1')->orderBy('id', 'DESC')->limit(20)->get();
	    $channel =[
	    		'title' => 'Qlevers - RSS', 
	    		'description' => 'Qlevers adalah sebuah situs belajar dan tanya jawab online yang menghubungkan para pelajar di indonesia', 
	    		'link' => URL::route('rss')
				];

	    $feed = Rss::feed('2.0', 'UTF-8');

	    $feed->channel($channel);

	    foreach ($topics as $topic)
	    {
	        $feed->item([
	                    'title' => 'Pertanyaan '.$topic->mapel->title, 
	                    'link' => URL::to('/ask/tugas', $topic->id), 
	                    'description|cdata' => str_limit($topic->body, 200), 
	                    'language' => 'en-US',
	                    'pubDate' => $topic->created_at, 
	                    'dc:creator|cdata'=> $topic->user->first_name.' '.$topic->user->last_name,
	                    'category|cdata' => $topic->mapel->title, 
	                    'category|cdata' => 'qlevers', 
	                    'category|cdata' => 'qlevers.com', 

	                ]);
	    }

	    return Response::make($feed, 200, array('Content-Type' => 'text/xml'));
	}

	public function getRssAbout()
	{
	    $topics = Article::with('menu')->where('active','=','1')->limit(20)->get();
	    $channel =[
	    		'title' => 'Qlevers - About RSS', 
	    		'description' => 'Qlevers adalah sebuah situs belajar dan tanya jawab online yang menghubungkan para pelajar di indonesia', 
	    		'link' => URL::route('rss')
				];

	    $feed = Rss::feed('2.0', 'UTF-8');

	    $feed->channel($channel);

	    foreach ($topics as $topic)
	    {
	        $feed->item([
	                    'title' => $topic->title, 
	                    'link' => URL::to('/pages'.'/'.$topic->menu->id.'/'.date('Y-m-d',strtotime($topic->menu->created_at)).'/'.$topic->menu->slug), 
	                    'description|cdata' => str_limit($topic->body, 200), 
	                    'language' => 'en-US',
	                    'pubDate' => $topic->created_at,
	                    'category|cdata' => $topic->menu->title, 
	                    'category|cdata' => 'qlevers', 
	                    'category|cdata' => 'qlevers.com', 

	                ]);
	    }

	    return Response::make($feed, 200, array('Content-Type' => 'text/xml'));
	}

	public function getRssTeam()
	{
	    $topics = Founder::with('menu')->where('active','=','1')->limit(20)->get();
	    $channel =[
	    		'title' => 'Qlevers - Team RSS', 
	    		'description' => 'Qlevers adalah sebuah situs belajar dan tanya jawab online yang menghubungkan para pelajar di indonesia', 
	    		'link' => URL::route('rss')
				];

	    $feed = Rss::feed('2.0', 'UTF-8');

	    $feed->channel($channel);

	    foreach ($topics as $topic)
	    {
	        $feed->item([
	                    'title' => $topic->nama.' - '.$topic->jabatan, 
	                    'link' => URL::to('/team'.'/'.$topic->id.'/'.date('Y-m-d',strtotime($topic->created_at)).'/'.$topic->slug), 
	                    'description|cdata' => str_limit($topic->tentang, 200), 
	                    'language' => 'en-US',
	                    'pubDate' => $topic->created_at,
	                    'category|cdata' => $topic->jabatan, 
	                    'category|cdata' => 'qlevers', 
	                    'category|cdata' => 'qlevers.com', 
	                ]);
	    }

	    return Response::make($feed, 200, array('Content-Type' => 'text/xml'));
	}

	public function getRssBlog()
	{
		$topics = BlogArticles::with('bcat')->where('active','=','1')->orderBy('id', 'desc')->limit(20)->get();
	    $channel =[
	    		'title' => 'Qlevers - Blog RSS', 
	    		'description' => 'Qlevers adalah sebuah situs belajar dan tanya jawab online yang menghubungkan para pelajar di indonesia', 
	    		'link' => URL::route('rss')
				];

	    $feed = Rss::feed('2.0', 'UTF-8');

	    $feed->channel($channel);

	    foreach ($topics as $topic)
	    {
	        $feed->item([
	                    'title' => $topic->title, 
	                    'link' => URL::to('/read/'.$topic->id.'/'.date('Y-m-d',strtotime($topic->created_at)).'/'.$topic->slug), 
	                    'description|cdata' => str_limit($topic->description, 200), 
	                    'language' => 'en-US',
	                    'pubDate' => $topic->created_at,
	                    'category|cdata' => $topic->title, 
	                    'category|cdata' => 'qlevers', 
	                    'category|cdata' => 'qlevers.com', 
	                ]);
	    }

	    return Response::make($feed, 200, array('Content-Type' => 'text/xml'));
	}

	public function getBlog()
	{
		return View::make('frontend.blog.list');
	}

	public function getCatBlog($id)
	{
		$brid = BlogCategories::where('active','=','1')->find($id);
		$list = BlogArticles::with('bcat')->where('active','=','1')->where('id_categories','=',$id)->orderBy('id', 'desc')->paginate(10);
		return View::make('frontend.blog.archive', compact('list','brid'));
	}

	public function getReadBlog($id)
	{
		$read = BlogArticles::with('bcat')->where('active','=','1')->find($id);
		return View::make('frontend.blog.read', compact('read'));
	}

}