<?php

use basicAuth\Repo\UserRepositoryInterface;
use basicAuth\formValidation\RegistrationForm;
use basicAuth\formValidation\UsersEditForm;

class RegistrationController extends \BaseController {

	/**
	 * @var $user
	 */
	protected $user;

	/**
	 * @var RegistrationForm
	 */
	private $registrationForm;

	/**
	* @var usersEditForm
	*/
	protected $usersEditForm;


	function __construct(UserRepositoryInterface $user, RegistrationForm $registrationForm, UsersEditForm $usersEditForm)
	{
		$this->user = $user;
		$this->registrationForm = $registrationForm;
		$this->usersEditForm = $usersEditForm;
	}



	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create()
	{
		return View::make('frontend.pages.static.register');
	}

	public function getKelas()
	{
		$input = Input::get('option');
    	$cat = Kelas::where('id_jenjang', '=', $input)->get();
    	return Response::json($cat, 200);
	}
	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{

		$input = Input::only('email', 'password', 'password_confirmation', 'no_contact', 'first_name', 'last_name','id_jenjang','id_kelas');

		$this->registrationForm->validate($input);

		$input = Input::only('email', 'password', 'no_contact', 'first_name', 'last_name','id_jenjang','id_kelas');
		$input = array_add($input, 'activated', true);
		$input = array_add($input, 'verification', true);

		$user = $this->user->create($input);

		// Find the group using the group name
    	$usersGroup = Sentry::findGroupByName('Users');

    	// Assign the group to the user
    	$user->addGroup($usersGroup);

		return Redirect::to('/pages/login')->withFlashMessage('User Successfully Created!');
	}

}